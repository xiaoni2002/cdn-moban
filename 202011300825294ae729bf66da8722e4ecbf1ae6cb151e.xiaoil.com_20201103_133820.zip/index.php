<?php
error_reporting(0);
date_default_timezone_set('PRC');
if(!empty($_GET['u'])){header('Location: '.gzuncompress(base64_decode($_GET['u'])));exit;}
define('CONFIG','./config');
define('PLUS','./plus');
define('KERNEL','./kernel');
define('DATA','./data');
$静态CDN='https://cdn.91dm.xyz';
include CONFIG.'/config.php';
include CONFIG.'/plus.php';
include CONFIG.'/guanggao.php';
include CONFIG.'/url.php';
include KERNEL.'/global.php';
$地址参数=地址参数();
$插件=插件排序();
$分类=分类();
$标签=标签();
$友链=友链();
foreach($插件 as $v){include PLUS.'/'.$v.'/head.php';}
foreach($插件 as $v){include PLUS.'/'.$v.'/index.php';}

include muban('./muban/'.MUBAN.'/'.$地址参数['sort'].'.php');

