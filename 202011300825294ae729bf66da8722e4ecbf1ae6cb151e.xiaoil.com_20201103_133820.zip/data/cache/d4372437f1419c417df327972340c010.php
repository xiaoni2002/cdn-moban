<?php include muban("./muban/xiaoni/head.php");?>
<div class="m-navbar-start">
                <i class="huisem huisem-caidan"></i>
            </div>
            
            <div class="m-mask"></div>
        </div>
    </div>
</div>
<div class="container">
    <div class="content-wrap">
        <div class="content">
                            
<div class="article-container">
    <header class="article-header">
        <h1 class="article-title"><?php echo $内容[name];?></h1>
        <div class="article-meta"><span class="item">作者：<a href="<?php echo 地址("list key:author id:$内容[author]");?>" title="<?php echo $内容[author];?>"><?php echo $内容[author];?></a>&nbsp;&nbsp;分类：<a href="<?php echo 地址("list key:type id:$内容[type]");?>" title="<?php echo $内容[typename];?>"><?php echo $内容[typename];?></a>&nbsp;&nbsp;阅读：<em><?php echo $内容[dj];?> </em> 次&nbsp;&nbsp;<!-- 评论：<em>2 </em> 次 --></span><span class="item">更新于：<?php echo date("Y-m-d h:i:s",$内容[gxtime]);?></span></div>
    </header>
        <article class="article-content">
        <?php echo $内容[text];?>    </article>
    <div class="clearfix">
        <div class="posttheme"><a target="_blank"  class="btn btn-hot">非特殊说明，本文版权归 <?php echo $内容[author];?> 所有，转载请注明出处.</a></div>

        <div class="xshare">
            <!-- 分享代码 -->
        </div>
    </div>
        </div>
       
<!-- 留言 -->
<section class="article-item zoomIn article">
                    <iframe src="https://1syan.com/?sort=bbs" width="100%" height="600px" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes" id="yk_bbs"></iframe>
                    </section>
    </div>
        </div>
    
    
<!-- 结束开始侧面   -->
<div class="sidebar">
            
<div class="widget" id="so">
    <h3 class="widget-title">搜索</h3>        <div class="divSearchPanel clearfix">
        <div name="search"><input type="text" name="q" size="11" placeholder="输入关键词回车搜索" onfocus="" onblur="" onkeypress="if(event.keyCode=='13'){var hrr='<?php echo 地址("list key:name id:keyword");?>';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);}" id="keywords"/> <input type="submit" value="搜索" onclick="var hrr='<?php echo 地址("list key:name id:keyword");?>';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);"/></div>    </div>
        </div>
        <!-- 电脑搜索 -->
<div class="widget">
    <h3 class="widget-title">热门文章</h3>            <ul class="divPrevious clearfix">
    <?php $文章c=读写删("搜索","key:state=>on str:dj cou:8");?>
                        <?php foreach($文章c[id] as $k=>$v){?>
                    <?php $文章=读写删("读取","id:$v str:name");?> 
<li><a href="<?php echo 地址("read id:$v");?>"><?php echo $文章[name];?></a></li><?php }?>
    </ul>
    </div>
<!-- 热门文章 -->
<div class="widget">
    <h3 class="widget-title">最新文章</h3>            <ul class="divPrevious clearfix">
    <?php $文章c=读写删("搜索","key:state=>on str:gxtime cou:8");?>
                        <?php foreach($文章c[id] as $k=>$v){?>
                    <?php $文章=读写删("读取","id:$v str:name");?>
<li><a href="<?php echo 地址("read id:$v");?>"><?php echo $文章[name];?></a></li><?php }?>
    </ul>
    </div>
<!-- 最新文章 -->
       
<div class="widget">
    <h3 class="widget-title">标签云</h3>            <ul class="divTags clearfix">
<?php $标签2[fl]=array_rand($标签[fl],10);;?> 
                            <?php foreach($标签2[fl] as $k=>$v){?>
                            <?php $过度=$标签[fl][$v];?>
<li><a href="<?php echo 地址("list key:tag id:$过度");?>"><?php echo $标签[info][$过度][name];?><span class="tag-count"><?php echo $标签[info][$过度][name];?></span></a></li>
<?php }?>

    </ul>
    </div>
<!-- 标签云        -->
<div class="widget">
    <h3 class="widget-title">友情链接</h3>            <ul class="divLinkage clearfix">
<?php foreach($友链 as $k=>$v){?>
<li><a href="<?php echo $v[link];?>" target="_blank" title="<?php echo $v[name];?>"><?php echo $v[name];?></a></li><?php }?>
            </ul>
    </div>    </div></div>
<!-- 友情 -->



<?php include muban("./muban/xiaoni/foot.php");?>