<!DOCTYPE html>
<html xml:lang="zh-Hans" lang="zh-Hans">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="X-UA-Compatible" content="ie=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="renderer" content="webkit">
<meta name="apple-mobile-web-app-title" content="<?php include $标题;?>">
<meta http-equiv="Cache-Control" content="no-siteapp">
<title><?php include $标题;?></title>
    <!-- Nobird_Seo_Tools Start -->

<!-- Nobird_Seo_Tools End -->
<meta name="keywords" content="<?php include $关键词;?>">
<meta name="description" content="<?php include $描述;?>">
<link rel="stylesheet" rev="stylesheet" href="/muban/xiaoni/xiaoni/style/style.css?v=11" type="text/css" media="all"/>
<script src="/muban/xiaoni/xiaoni/script/jquery-2.2.4.min.js" type="text/javascript"></script>

<!--[if lt IE 9]>
<![endif]-->
<link href="/muban/xiaoni/xiaoni/static/style/style.css" type="text/css" rel="stylesheet" />
<script src="/muban/xiaoni/xiaoni/static/script/functions.js"></script>
<link rel="alternate" type="application/rss+xml" href="/sitemap.xml" title="<?php include $标题;?>" />
<script type="text/javascript">
var art_cate_url='';
</script>
</head><body class="index">

<div class="header">
    <div id="header_main">
        <div class="container">
            <h1 class="logo"><a href="/"><img src="/muban/xiaoni/xiaoni/images/logo.png" alt="<?php include $标题;?>"></a></h1>
                        
            <div class="site-navbar">
                <ul>
                    <li<?php if($地址归类=='index'){?> class="on"<?php }?>><a href="/">首页</a></li>
<?php foreach($分类[info] as $分类号=>$分类名){?><?php if($分类名[state]=='on'){?>
                    <li<?php if($分类号==$内容[type]){?> class="on"<?php }else{?>
                   <?php if($分类号==$地址参数[id] and $地址参数[key]=='type'){?> class="on"<?php }?>
                   <?php }?>>
                    <a href="<?php echo 地址("list key:type id:$分类号");?>"><?php echo $分类名[name];?></a></li>
                     <?php }?><?php }?>
                    <li class="has-sub-menu"><a href="#">教程分类</a><div class="sub-menu"><ul>
                     <li><a href="/sort/4.html">PHP教程</a></li>
                     <li><a href="/sort/5.html">HTML5教程</a></li>
                     <li><a href="/sort/6.html">jquery教程</a></li>
                     <li><a href="/sort/7.html">seo优化</a></li>
                     </ul></div></li>
                    <!--<li<?php if($地址参数[sort]=='kan'){?> class="on"<?php }?>><a href="/kan/.html">博客影视</a></li>-->
                    <li<?php if($地址参数[sort]=='bbs'){?> class="on"<?php }?>><a href="/bbs.html">留言板</a></li>
                                    </ul>
            </div>
<?php 
// print_r($分类名);
 ?>
