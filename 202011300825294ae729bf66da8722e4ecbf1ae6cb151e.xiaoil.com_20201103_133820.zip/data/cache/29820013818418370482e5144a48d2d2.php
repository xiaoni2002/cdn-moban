<?php include muban("./muban/xiaoni/head.php");?>
<?php 
// print_r($地址参数);
 ?>
<style type="text/css">
.visible-xs {display: none;}@media (max-width: 767px) {.visible-xs {display: block !important;}}/*手机显示*/
.hidden-xs {display: block;}
@media (max-width: 768px){.hidden-xs{display: none;}/*电脑显示*/
</style>
 <div class="m-navbar-start">
                <i class="huisem huisem-caidan"></i>
            </div>
            
            <div class="m-mask"></div>
        </div>
    </div>
</div>
<style type="text/css">
.contentt {
    margin-left: 0;
    margin-right: 0px;
}</style>
      <div class="container">

        <div class="contentt">
<?php if($地址归类=='index'){?>
<div class="focus-slider flexslider">
    <ul class="slides">
        <li>
            <div class="hdfocus" style="background-image: url(/muban/xiaoni/xiaoni/images/bg1.png);">
                <div class="container">
                    <h2>筱昵工作室 全新起航</h2>
                    <h3>我们为您提供更专业的 XN-CMS 主题、插件定制开发服务，专注于分享 XN-CMS 教程、主题、插件资源！</h3>
                                        <div class="button">
                        
                    </div>
                                    </div>
            </div>
        </li>
        <li>
            <div class="hdfocus" style="background-image: url(/muban/xiaoni/xiaoni/images/bg3.png);">
                <div class="container">
                    <!--<h2>更专业的 XN-CMS 主题</h2>-->
                    <!--<h3>新型 XN-CMS 主题开发 &nbsp; / &nbsp; 高端大气用户体验 &nbsp; / &nbsp; 全设备自适应兼容 &nbsp; / &nbsp; 免费靠谱工单售后</h3>-->
                                        <div class="button">
                        
                    </div>
                                    </div>
            </div>
        </li>
        
    </ul>
</div>
<?php }else{?>
<div class="tbfocus">
    <div class="container">
        <h1><?php if($地址参数[key]=="type"){?><?php echo $分类[info][$地址参数[id]][name];?><?php }elseif($地址参数[key]=="tag"){?><?php echo $标签[info][$地址参数[id]][name];?><?php }elseif($地址参数[key]=="name"){?><?php echo $地址参数[id];?><?php }else{?>文章列表<?php }?></h1>
        <h5></h5>
    </div>
</div>
<?php }?>
<div class="posts-default visible-xs">
 <div class="search">
                        <label class="search-wrap">
                            <input type="text" id="keyword" placeholder="输入关键字搜索" onkeypress="if(event.keyCode=='13'){var hrr='<?php echo 地址("list key:name id:keyword");?>';window.location.href=hrr.replace(/keyword/,document.getElementById('keyword').value);}"/>
                            <span class="search-icon">
                                    <i  onclick="var hrr='<?php echo 地址("list key:name id:keyword");?>';window.location.href=hrr.replace(/keyword/,document.getElementById('keyword').value);" id="serachs"></i>
                                </span>
                        </label>
                    </div>
                   </div>
  </div>
    </div>
<div class="container">
    <div class="content-wrap">
        <div class="content">

<!-- 结束开始列表 -->
<?php foreach($内容[id] as $k=>$v){?>
                    <?php $文章=读写删("读取","id:$v str:name|author|type|gxtime|dj|url|sub|con|tag|yc");?> 
<div class="posts-default">
    <h2><span class="post-icon"><i class="huisem huisem-huo"></i></span><a href="<?php echo 地址("read id:$v");?>" title="<?php echo $文章[name];?>" target="_blank">【<?php echo $文章[yc];?>】<?php echo $文章[name];?></a><?php foreach($文章[tagid] as $vs=>$ks){?><a class="sj" href="<?php echo 地址("list key:tag id:$ks");?>"><?php echo $文章[tag][$vs];?></a><?php }?></h2>
        <div class="thumbnail">                                                                                                                                           
        <a href="<?php echo 地址("read id:$v");?>" target="_blank"><img src="<?php if($文章[fm]){?><?php echo $文章[fm];?><?php }else{?>/muban/xiaoni/xiaoni/images/bg2.png<?php }?>" alt="<?php echo $文章[name];?>"></a>
    </div>
        <p class="intro"><?php echo $文章[mate];?></p>
    <div class="intro-meta">
        <span class="cate">分类：<a href="<?php echo 地址("list key:type id:$内容[type]");?>" title="<?php echo $分类[info][$文章[type]][name];?>"><?php echo $分类[info][$文章[type]][name];?></a>&nbsp;&nbsp; 阅读：<em><?php echo $文章[dj];?></em> 次&nbsp;&nbsp; 作者：<?php echo $文章[author];?></span>
        <span class="time"><?php echo date("Y",$文章[gxtime]);?>-<?php echo date("m",$文章[gxtime]);?>-<?php echo date("d",$文章[gxtime]);?></span>
    </div>
</div>

<?php }?>
<!-- 列表结束下一页开始 -->                                        
<div class="pagination"><ul>
        <li><a href="<?php echo 地址("list key:$地址参数[key] id:$地址参数[id] page:1");?>">首页</a></li>
        <li><a href="<?php echo 地址("list key:$地址参数[key] id:$地址参数[id] page:$内容[prepage]");?>">上一页</a></li>
        <li class="active"><span><?php echo $地址参数[page];?>/<?php echo $内容[count];?></span></li>
        <li><a href="<?php echo 地址("list key:$地址参数[key] id:$地址参数[id] page:$内容[nexpage]");?>">下一页</a></li>
        <li class="next-page"><a href="<?php echo 地址("list key:$地址参数[key] id:$地址参数[id] page:$内容[prepage]");?>">上一页</a></li>
        <li class="pages-num"><a href="javascript:;"><?php echo $地址参数[page];?>/<?php echo $内容[count];?></a></li>
        <li><a href="<?php echo 地址("list key:$地址参数[key] id:$地址参数[id] page:$内容[count]");?>">尾页</a></li>
        <li class="next-page"><a href="<?php echo 地址("list key:$地址参数[key] id:$地址参数[id] page:$内容[nexpage]");?>">下一页</a></li>
</ul></div>
        </div>
    </div>
<!-- 结束开始侧面   -->
<div class="sidebar">
            
<div class="widget hidden-xs" id="so">
    <h3 class="widget-title">搜索</h3>        <div class="divSearchPanel clearfix">
        <div name="search"><input type="text" name="q" size="11" placeholder="输入关键词回车搜索" onfocus="" onblur="" onkeypress="if(event.keyCode=='13'){var hrr='<?php echo 地址("list key:name id:keyword");?>';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);}" id="keywords"/> <input type="submit" value="搜索" onclick="var hrr='<?php echo 地址("list key:name id:keyword");?>';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);"/></div>    </div>
        </div>
        <!-- 电脑搜索 -->
<div class="widget">
    <h3 class="widget-title">热门文章</h3>            <ul class="divPrevious clearfix">
    <?php $文章c=读写删("搜索","key:state=>on str:dj cou:8");?>
                        <?php foreach($文章c[id] as $k=>$v){?>
                    <?php $文章=读写删("读取","id:$v str:name");?> 
<li><a href="<?php echo 地址("read id:$v");?>"><?php echo $文章[name];?></a></li><?php }?>
    </ul>
    </div>
<!-- 热门文章 -->
<div class="widget">
    <h3 class="widget-title">最新文章</h3>            <ul class="divPrevious clearfix">
    <?php $文章c=读写删("搜索","key:state=>on str:gxtime cou:8");?>
                        <?php foreach($文章c[id] as $k=>$v){?>
                    <?php $文章=读写删("读取","id:$v str:name");?>
<li><a href="<?php echo 地址("read id:$v");?>"><?php echo $文章[name];?></a></li><?php }?>
    </ul>
    </div>
<!-- 最新文章 -->
       
<div class="widget">
    <h3 class="widget-title">标签云</h3>            <ul class="divTags clearfix">
<?php $标签2[fl]=array_rand($标签[fl],10);;?> 
                            <?php foreach($标签2[fl] as $k=>$v){?>
                            <?php $过度=$标签[fl][$v];?>
<li><a href="<?php echo 地址("list key:tag id:$过度");?>"><?php echo $标签[info][$过度][name];?><span class="tag-count"><?php echo $标签[info][$过度][name];?></span></a></li>
<?php }?>

    </ul>
    </div>
<!-- 标签云        -->
<div class="widget">
    <h3 class="widget-title">友情链接</h3>            <ul class="divLinkage clearfix">
<?php foreach($友链 as $k=>$v){?>
<li><a href="<?php echo $v[link];?>" target="_blank" title="<?php echo $v[name];?>"><?php echo $v[name];?></a></li><?php }?>
            </ul>
    </div>    </div></div>
<!-- 友情 -->
<?php include muban("./muban/xiaoni/foot.php");?>