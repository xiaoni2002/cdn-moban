<?php include muban("./muban/xiaoni/head.php");?>
<?php 
$info=file_get_contents("http://cj.okzy.tv/inc/feifei3ckm3u8/?vodids=".$地址参数['page']);     //接口地址
$new=json_decode($info,true);//格式化
foreach ($new[data] as $v)
$过度=str_replace("$","TIHUAN",$v[vod_url]);
// print_r($过度);
preg_match_all('#(.*?.)TIHUAN(.*?.).m3u8#',$过度,$影视);
// print_r($new);
 ?>

<div class="m-navbar-start">
                <i class="huisem huisem-caidan"></i>
            </div>
            
            <div class="m-mask"></div>
    

<div class="m-navbar-start">
                <i class="huisem huisem-caidan"></i>
            </div>
            
            <div class="m-mask"></div>
        </div>
    </div>
</div>
<div class="container">
    <div class="content-wrap">
        <div class="content">
<?php 
// print_r($地址参数);
// print_r($地址);
 ?>


<link rel="stylesheet" href="/muban/xiaoni/xiaoni/007/bootstrap.min.css">
<link href="/muban/xiaoni/xiaoni/007/swiper.min.css" rel="stylesheet" type="text/css">     
<link href="/muban/xiaoni/xiaoni/007/iconfont.css" rel="stylesheet" type="text/css">
<link href="/muban/xiaoni/xiaoni/007/style.min.css" rel="stylesheet" type="text/css">
<script src="/muban/xiaoni/xiaoni/007/amazeui.2.7.2min.js"></script>

<style>

.apptop {padding-top: 0px;}
.hy-play-list .item .panel .playlist ul li a {display: list-item;}
#xlu {display: block;/* background:rgba(0,0,0,0.5); */padding: 6px 2px;text-align: center;}
@media (max-width: 990px){.hy-player .item .sidebar {height: auto;}}
a.nowplay{background-color:rgba(26, 156, 214, 0.61)!important;color: #fff!important;}
a.nowxl{background-color:rgba(26, 156, 214, 0.61)!important;color: #fff!important;}
a.nowly{background-color:rgba(26, 156, 214, 0.61)!important;color: #fff!important;}
a.nowyear{background-color:rgba(26, 156, 214, 0.61)!important;color: #fff!important;}
.playlistlink-2 img{height:  90px;border-radius: 5px;}
.playfloat{z-index: 9999999999!important;position: fixed!important;top: -25px!important;left: 0!important;width: 100%!important;height: 40%!important;border: 0!important;
}

</style><script>
function s007(urls,xlmz){
    var store = $.AMUI.store;
    store.set('jkapi',urls);
    store.set('jkname',xlmz);
    var videourls = document.getElementById('video');
    var xlqieh = document.getElementById('videourlgo');
    videourls.src = urls+xlqieh.href;
    document.getElementById('xl').innerHTML =xlmz;
    sss07=urls;
}
</script>
<script type="text/javascript">
 var store = $.AMUI.store;
 store.set('jkapi','http://17kju.com/api.php?url=');
function bofang(mp4url, jiid) {
    $('.yzbf').attr('href', mp4url);
    var store = $.AMUI.store;
    var jkapi07 = store.get('jkapi') ? store.get('jkapi') : 'http://17kju.com/api.php?url=';
    //var jkapi07 = '/jk/HByun/?url=';
    if (jiid != 0) {
        document.getElementById('playji').innerHTML = jiid;
    }
    document.getElementById('videourlgo').href = mp4url;
    if (mp4url.indexOf('hanju.cc') >= 0){document.getElementById('video').src = jkapi07 + mp4url;
    }else if (mp4url.indexOf('360kan.com/sv/') >= 0){
        document.getElementById('video').src = jkapi07 + mp4url;
             }
          else{
               document.getElementById('video').src = jkapi07 + mp4url;
               }
    /* if (store.get('jkname') != null) {
        document.getElementById('xl').innerHTML = store.get('jkname');
    } */
    store.set('myji1', jiid);
    store.set('fangurl1', mp4url);
    jiid = null;
    if ($(window).width() >= '992') {
        document.getElementById('jiachang').style.height = '670px';
    }
    
    document.getElementById('xlu').style.display = 'block';
    detailJi();    rejilu();
};
</script><style>
.skkk{width: 100%;text-align: center;}
#sk a {margin-left:15px; } 
@media (min-width: 844px){.newji0707{display:none;}   }
@media (max-width: 843px){.newji0707{display:none;}  .skkk{display:inline-block;}}

</style></head>




    

<body class="vod-type apptop">
         
<div class="container">
    <div class="content-wrap">
        <div class="content">
        <div class="hy-player clearfix">
            <div class="item">
                <div class="col-md-9 col-sm-12 padding-0">
                <div class="seat" style="display: none; background-color: rgb(0, 0, 0); width: 878px; height: 540px;"></div>
                    <div class="info embed-responsive embed-responsive-4by3" style="" id="cms_player">
                    <iframe title="<?php echo $v[vod_name];?>-正在播放" id="video" name="ajax" src='//17kju.com/api.php?url=<?php echo $影视[2][0].'.m3u8'; ?>&playmz=<?php echo $v[vod_name];?>&playji=1' class="embed-responsive-item" autoplay="autoplay" allowtransparency="true" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" scrolling="No" width="100%" height="100%"></iframe><a style="display:none" id="videourlgo"  ></a>
                    </div>
                    <div class="footer clearfix">
                        
                        <span style="font-size:15px;" id="playsite"><span id="mz">《<?php echo $v[vod_name];?>》</span><span id="playji" style="color: #edaf01;">第1集</span><span style="color: #1a9cd6;margin-left: 9px;" id="xl">线路1</span></span>
</div>
                <div class="footer clearfix newji0707" style="display: none;"><span id="ntji" class="skkk" style="display:;"><div id="sk" style="    ">
        </div>              
                    </span></div>


<!-- 路线开始 -->
                  <div class="footer clearfix" id="xlu" style="height: auto; display: block;"> 
   <span class="text-muted">
   <a onclick="s007('http://17kju.com/api.php?url=','线路1')" class="btn btn-sm btn-default nowxl">线路1</a>
   <a onclick="s007('//jx.mxo1.cn/api/?url=','线路2')" class="btn btn-sm btn-default">线路2</a>
   <a onclick="s007('http://jsap.attakids.com/?url=','线路3')" class="btn btn-sm btn-default">线路3</a>
   <a onclick="s007('//jx.618g.com/?url=','线路4')" class="btn btn-sm btn-default">线路4</a>
   <a onclick="s007('//jx.7cyd.com/?url=','线路5')" class="btn btn-sm btn-default">线路5</a>
    <a onclick="s007('//jx.yingxiangbao.cn/vip.php?url=','线路6')" class="btn btn-sm btn-default">线路6</a> </span> 
  </div>
  <div class="col-lg-12 col-md-6 col-sm-7 single-faculty posts-default">

<ul class="divTags  clearfix">
<?php
foreach ($影视[1] as $v => $影视名称) { $影视地址=$影视[2][$v].'.m3u8';?>
<li class="j007"><a href="javascript:void(0)" target="_self" id="btn-danger" class="btn btn-danger 1 nowplay" onclick="bofang('<?php echo $影视地址;?>&playmz=三生&playji=1','<?php echo $影视名称;?>')"><?php echo $影视名称;?></a></li>
<!-- <li><a data="<?php echo $影视地址;?>" class="genric-btn info-border radius" title="<?php echo $影视名称;?>"><?php echo $影视名称;?></a></li> -->
<?php }?>
 
</ul>
                  
                </div>
<!-- 路线结束 -->
                </div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                

                
                
                


<script>
$(refreshji());
 $(".hy-play-list").on("click", ".btn-danger", function() {
 $(".btn-danger").removeClass("nowplay");
 $(this).addClass("nowplay");
 refreshji();

/*  layer.msg("正在为您播放：《<?php echo $v[vod_name];?>》 " + $(this).text()); */
 layer.tips('小7提示：若不能播放，请切换线路！', '.nowplay', {
  tips: [1, 'rgba(53, 149, 204, 0.85)'],
  time: 6000
});
//setTimeout(function () { $('body,html').animate({scrollTop:0},1000); }, 3500); 
 
 })
</script>
<script>
$("#xlu").on("click",".btn-default", function() {
$(".btn-default").removeClass("nowxl");
$(this).addClass("nowxl");      
layer.tips('小7提示：若全部线路不能播放，请切换播放来源！', '.nowxl', {
  tips: [1, 'rgba(53, 149, 204, 0.75)'],
  time: 6000
});     
});
</script>
<script>
hbJirecord=0;
function next007(){
var next07 = $(".nowplay");
            if(next07!=null){
                hbJirecord=next07.parent().next().index();
                next07.parent().next().children(0).click(); }
}
 function prev007(){
var pre07 = $(".nowplay");
            if(pre07!=null){
                pre07.parent().prev().children(0).click();
 } }
</script>

<script>
        var swiper = new Swiper('.hy-switch', {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            slidesPerView: 5,
            spaceBetween: 0,
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            breakpoints: {
                1200: {
                    slidesPerView: 4,
                    spaceBetween: 0
                },
                767: {
                    slidesPerView: 3,
                    spaceBetween: 0                             
                }
            }
        });  
</script>
                        

<div style="display: none;"></div>

<script>
if ((location.href || '').indexOf('hb..') > -1) {
    document.write("<script src='https://cdn.bootcss.com/vConsole/3.3.0/vconsole.min.js'><\/script>");
    document.write("<script>new VConsole()<\/script>");
}
</script>
<style>
    @media all and (orientation : landscape) {
        .tabbar {
            bottom: -25px;
        }
        .tabbar .item .text {
            display: none!important;
        }
        @media (max-width: 768px){
        .col-xs-4 {width: 12.333333%}
        }
        .videopic {
           /* padding-top: 100%;*/
        }
    }


/* autocomplete */
.autocomplete-suggestions{padding:0 10px;margin-top:5px;border-radius:4px}.autocomplete-suggestions.active{position:absolute;z-index:9999;top:100%;width:100%}.autocomplete-suggestion{padding:10px 0;cursor:pointer}.autocomplete-suggestion:first-child{border-top:0}.autocomplete-suggestions{background-color:rgba(0,0,0,.7);border:1px solid rgba(0,0,0,.5);box-shadow:0 2px 10px rgba(0,0,0,.05)}.autocomplete-suggestion{border-top:1px solid rgba(204,204,204,.2)}

@media (max-width: 767px){
.tabbar {width: 100%!important;}
.tabbar .item { width: 16.6%!important;}
.autocomplete-suggestions.active{width: 95%;}
}

</style>
<style>
.light { display:block;  position: relative;  margin:0 auto;overflow: hidden;}
.light:before { 
content: ""; position: absolute; width:200px; height: 100%; top: 0; left: -150px; overflow: hidden;
background: -moz-linear-gradient(left, rgba(255,255,255,0)0, rgba(255,255,255,.2)50%, rgba(255,255,255,0)100%);
background: -webkit-gradient(linear, left top, right top, color-stop(0%, rgba(255,255,255,0)), color-stop(50%, rgba(255,255,255,.2)), color-stop(100%, rgba(255,255,255,0)));
background: -webkit-linear-gradient(left, rgba(255,255,255,0)0, rgba(255,255,255,.2)50%, rgba(255,255,255,0)100%);
background: -o-linear-gradient(left, rgba(255,255,255,0)0, rgba(255,255,255,.2)50%, rgba(255,255,255,0)100%);
-webkit-transform: skewX(-25deg);
-moz-transform: skewX(-25deg)
}
.light:hover:before { left: 150%; transition: left 0.71s ease 0s; }
</style>
 
   <script type="text/javascript" src="/muban/xiaoni/xiaoni/007/suggestion.js"></script>
   <script src="/muban/xiaoni/xiaoni/007/amazeui.2.7.2min.js"></script>
    












  <!-- 播放地址--> 
</div>

  <!-- 结束开始侧面   -->
<div class="sidebar">
            
<div class="widget" id="so">
    <h3 class="widget-title">搜索</h3>        <div class="divSearchPanel clearfix">
        <div name="search"><input type="text" name="q" size="11" placeholder="输入关键词回车搜索" onfocus="" onblur="" onkeypress="if(event.keyCode=='13'){var hrr='<?php echo 地址("kan key:name id:keyword");?>';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);}" id="keywords"/> <input type="submit" value="搜索" onclick="var hrr='<?php echo 地址("kan key:name id:keyword");?>';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);"/></div>    </div>
        </div>
        <!-- 电脑搜索 -->
<div class="widget">
    <h3 class="widget-title">热门文章</h3>            <ul class="divPrevious clearfix">
    <?php $文章c=读写删("搜索","key:state=>on str:dj cou:8");?>
                        <?php foreach($文章c[id] as $k=>$v){?>
                    <?php $文章=读写删("读取","id:$v str:name");?> 
<li><a href="<?php echo 地址("read id:$v");?>"><?php echo $文章[name];?></a></li><?php }?>
    </ul>
    </div>
<!-- 热门文章 -->
<div class="widget">
    <h3 class="widget-title">最新文章</h3>            <ul class="divPrevious clearfix">
    <?php $文章c=读写删("搜索","key:state=>on str:gxtime cou:8");?>
                        <?php foreach($文章c[id] as $k=>$v){?>
                    <?php $文章=读写删("读取","id:$v str:name");?>
<li><a href="<?php echo 地址("read id:$v");?>"><?php echo $文章[name];?></a></li><?php }?>
    </ul>
    </div>
<!-- 最新文章 -->
       
<div class="widget">
    <h3 class="widget-title">标签云</h3>            <ul class="divTags clearfix">
<?php $标签2[fl]=array_rand($标签[fl],10);;?> 
                            <?php foreach($标签2[fl] as $k=>$v){?>
                            <?php $过度=$标签[fl][$v];?>
<li><a href="<?php echo 地址("list key:tag id:$过度");?>"><?php echo $标签[info][$过度][name];?><span class="tag-count"><?php echo $标签[info][$过度][name];?></span></a></li>
<?php }?>

    </ul>
    </div>
<!-- 标签云        -->
<div class="widget">
    <h3 class="widget-title">友情链接</h3>            <ul class="divLinkage clearfix">
<?php foreach($友链 as $k=>$v){?>
<li><a href="<?php echo $v[link];?>" target="_blank" title="<?php echo $v[name];?>"><?php echo $v[name];?></a></li><?php }?>
            </ul>
    </div>    </div></div>
<!-- 友情 -->
<!-- 用于图片懒加载 -->
  
             


<?php include muban("./muban/xiaoni/foot.php");?>