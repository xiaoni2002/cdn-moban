# file2link
- PHP利用Github与jsdelivr生成文件直链（对象存储/图床）

# 食用方法
- 打开api.php编辑name（github昵称）、username（github用户名）、email（github绑的邮箱）、token（有repo权限的token）、repo（repo名）
- Token申请地址 https://github.com/settings/tokens
- 传至php服务器
- 打开其中的index.php
- 即可使用
