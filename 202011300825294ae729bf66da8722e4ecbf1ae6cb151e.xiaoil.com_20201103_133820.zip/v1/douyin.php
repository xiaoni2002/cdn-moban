<?php 
$info=file_get_contents("http://xiaoni.cc/v1/douyin/?url=".$_GET['url']);     //接口地址
$new=json_decode($info,true);//格式化?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name=viewport content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no,minimal-ui">
    <meta name="referrer" content="no-referrer">
    <title><?php echo $new[name];?></title>
    <style type="text/css">
      html, body {width:100%;height:100%;margin:auto;overflow: hidden;}
    </style>
  </head>
  <body>
    <div id="mse"></div>
    <script src="//cdn.jsdelivr.net/npm/xgplayer@1.1.4/browser/index.js" charset="utf-8"></script>
      <script>
      let player = new Player({
		"id": "mse",
		"url": "<?php echo $new[url];?>",
		"playsinline": true,
		"whitelist": [
				""
		],
		"autoplay": true,
		"volume": 1,
		"fluid": true
      });
      
          </script>
  </body>
</html>
