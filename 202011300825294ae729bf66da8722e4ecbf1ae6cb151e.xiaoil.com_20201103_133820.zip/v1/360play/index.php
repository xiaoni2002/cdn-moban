<?php
function Curl($url,$guise,$UA){
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_REFERER, $guise);
  curl_setopt($curl, CURLOPT_USERAGENT, $UA);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array('X-FORWARDED-FOR:'.Rand_IP(), 'CLIENT-IP:'.Rand_IP()));
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLINFO_HEADER_OUT, TRUE);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
  $data = curl_exec($curl);
  curl_close($curl);
  $data=mb_convert_encoding($data, 'UTF-8', 'UTF-8,GBK,GB2312,BIG5');
  return $data;
}
function Rand_IP(){
    $ip2id = round(rand(600000, 2550000) / 10000);
    $ip3id = round(rand(600000, 2550000) / 10000);
    $ip4id = round(rand(600000, 2550000) / 10000);
    $arr_1 = array("218","218","66","66","218","218","60","60","202","204","66","66","66","59","61","60","222","221","66","59","60","60","66","218","218","62","63","64","66","66","122","211");
    $randarr= mt_rand(0,count($arr_1)-1);
    $ip1id = $arr_1[$randarr];
    return $ip1id.".".$ip2id.".".$ip3id.".".$ip4id;
}
$网站UA="Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.25 Safari/537.36 Core/1.70.3732.400 QQBrowser/10.5.3819.400";
$模拟网站='https://www.360kan.com/';
$data=Curl("https://www.360kan.com/".$_GET['url'],$模拟网站,$网站UA);
$分段=explode("/",$_GET['url']);
preg_match_all('#<h1>(.*?.)</h1>#',$data,$影视标题);//标题
// 判断加载播放列表
// print_r($分段);

if ($分段[0]=='m') {
preg_match_all('#<a data-daochu="to=(.*?)" class="btn js-site ea-site (.*?)" href="(.*?)">(.*?)</a>#',$data,$列表);
$return_data = array('title'=>$影视标题[1][0]);
$data = array_combine($列表[4],$列表[3]);//
foreach($data as $key=>$v){
    $return_data[]=array('name'=>$key,'url'=>$v);//再次变换
}
echo json_encode($return_data );
} else
// 动漫
if ($分段[0]=='ct') {
//正则开始
$过度=str_replace('<a href="####" class="js-slice-series-slide" style="width:126px;">收起</a></div><div class="series-slice-view g-clear js-series1" style="display:none;" >',"",$data);
//正则开始
preg_match_all('#<div class="series-slice-view g-clear js-series0">(.*?.)</div>#',$过度,$获取列表);
preg_match_all('#<a data-num="(.*?.)"data-daochu="to=(.*?.)" href="(.*?.)">#',$获取列表[1][0],$列表);
$return_data = array('title'=>$影视标题[1][0]);
$data = array_combine($列表[1],$列表[3]);//
foreach($data as $key=>$v){
    $return_data[]=array('name'=>$key,'url'=>$v);//再次变换
}
echo json_encode($return_data );
} else
// 电视
if ($分段[0]=='tv') {
//正则开始
preg_match_all('#<div class="num-tab-main g-clear\s*js-tab"\s*(style="display:none;")?>[\s\S]+?<a data-num="(.*?)" data-daochu="to=(.*?)" href="(.*?)">[\s\S]+?</div>#',$data,$tv);
$获取列表 = implode($glue, $tv[0]);
preg_match_all('<a data-num="(.*?)" data-daochu="to=(.*?)" href="(.*?)">',$获取列表,$列表);
$return_data = array('title'=>$影视标题[1][0]);
$data = array_combine($列表[1],$列表[3]);//
foreach($data as $key=>$v){
    $return_data[]=array('name'=>$key,'url'=>$v);//再次变换
}
echo json_encode($return_data );
} else
//综艺
if ($分段[0]=='va') {
//正则开始
preg_match_all('#<div data-block="tj-juji" class="juji-main-wrap">[\s\S]+?<div class="juji-page js-juji-page"#',$data,$zy);
$获取列表 = implode($glue, $zy[0]);
preg_match_all("#<span class='w-newfigure-hint'>(.*?)</span>#",$获取列表,$列表名字);
preg_match_all("#<a href='(.*?)' data-daochu=to=(.*?) class='js-link'><div class='w-newfigure-imglink g-playicon js-playicon'>#",$获取列表,$视频连接);
$return_data = array('title'=>$影视标题[1][0]);
$data = array_combine($列表名字[1],$视频连接[1]);//
foreach($data as $key=>$v){
    $return_data[]=array('name'=>$key,'url'=>$v);//再次变换
}
echo json_encode($return_data );
}
?>