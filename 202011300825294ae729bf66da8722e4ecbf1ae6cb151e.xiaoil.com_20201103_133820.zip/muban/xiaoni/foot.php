<div class="workorder-module" style="background-image: url(/muban/xiaoni/xiaoni/img/bottom-bg.jpg);">
    <div class="container">
        <div class="title-center title-center-white">
            <h3>介绍</h3>
        </div>
        <h4>还不知道要介绍点什么，先将就下。</h4>
        <p></p>
        <a class="download-now" href="/" target="_blank">筱昵博客</a>
    </div>
</div>
<!-- 介绍 -->
<div class="footer">
    <div class="container clearfix">
        <p>声明：本站所有主题/文章除标明原创外，均来自网络转载，版权归原作者所有，如果有侵犯到您的权益，请联系本站删除，谢谢合作！<br />Powered By <a href="/" title="RainbowSoft XN-CMS" target="_blank">XN-CMS1.0 PHP</a> <a href="https://www.beian.miit.gov.cn/" target="_blank">桂ICP备1000000号-1</a> <span class="hide"></span><a href="https://www.xiaoil.com/sitemap.xml" target="_blank">网站地图</a> Theme By 筱昵博客工作室</p>
    </div>
</div>
<!--<div class="wintips">-->
<!--    <div class="wintips-thumb">-->
<!--        <img src="/muban/xiaoni/xiaoni/images/flyman.png">-->
<!--    </div>-->
<!--    <h2>网站公告：</h2>-->
<!--    <p>本站全新开发的博客上线。</p>-->
<!--    <p>-->
<!--        <a href="/" class="btn btn-primary" target="_blank">加入我们</a>-->
<!--        <a href="/" class="btn btn-success"  style="margin-left:10px;">筱昵博客</a>-->
<!--    </p>-->
<!--    <span etap="wintips_close" class="wintips-close"><i class="huisem huisem-guanbi"></i></span>-->
<!--</div>-->
<script type="text/javascript" src="/muban/xiaoni/xiaoni/js/headroom.min.js"></script>
<script type="text/javascript" src="/muban/xiaoni/xiaoni/js/theia-sticky-sidebar.js"></script>
<script type="text/javascript" src="/muban/xiaoni/xiaoni/js/jquery.cookie.min.js"></script>
<script type="text/javascript" src="/muban/xiaoni/xiaoni/js/jquery.flexslider.js"></script>
<script type="text/javascript">$(function()\{$(".focus-slider").flexslider(\{animation: "slide"})});</script>
<script type="text/javascript" src="/muban/xiaoni/xiaoni/js/main.js"></script>
<div class="site-contact">
    <a class="btn btn-success" target="_blank" title="QQ {QQ}" href="http://wpa.qq.com/msgrd?v=3&amp;uin={QQ}&amp;site=qq&amp;menu=yes">联系QQ</a>
</div>
<script>
(function()\{
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') \{
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else \{
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<?php foreach($插件 as $v)\{include PLUS.'/'.$v.'/foot.php';}?>
</body>