{引用 ./muban/xiaoni/head.php}
<?php
$地址=explode('.html',$_SERVER['REQUEST_URI']);$地址=explode('/',$地址[0]);
if ($地址[3] == null)\{$地址[3]=1;}
$urllist="http://cj.okzy.tv/inc/feifei3ckm3u8/?cid=".$地址[2]."&p=".$地址[3]; 
mkdir('./data');
mkdir('./data/list');
$gxpd=time()-filemtime('./data/list/'.md5($urllist));
if($gxpd>1*60*60)\{
$info=file_get_contents($urllist);
file_put_contents('./data/list/'.md5($urllist),gzdeflate($info));
}
$new=json_decode(gzinflate(file_get_contents('./data/list/'.md5($urllist))),true);
// $info=file_get_contents("http://cj.okzy.tv/inc/feifei3ckm3u8/?cid=".$地址[2]."&p=".$地址[3]);     //接口地址
// $new=json_decode($info,true);//格式化
// print_r($new);
 ?>

<div class="m-navbar-start">
                <i class="huisem huisem-caidan"></i>
            </div>
            
            <div class="m-mask"></div>
    

<div class="m-navbar-start">
                <i class="huisem huisem-caidan"></i>
            </div>
            
            <div class="m-mask"></div>
        </div>
    </div>
</div>
<div class="container">
    <div class="content-wrap">
        <div class="content">
                <!--  -->

    <link href="/plus/XNYS/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="/plus/XNYS/css/style.min.css" rel="stylesheet" type="text/css" />
        <div class="hy-layout clearfix">
            <div class="hy-min-screen clearfix">
                <ul class="nav  nav-tabs">
                    <li class="active"><a>影视</a></li>
                    <li><a></a></li>
                </ul>


                <div class="item clearfix">
                    <div></div>
                                        <dl class="clearfix">
                        <dd class="clearfix">
                                                     
        <a href="/kan/5/1.html">动作片</a>
        <a href="/kan/6/1.html">喜剧片</a>
        <a href="/kan/7/1.html">爱情片</a>
        <a href="/kan/8/1.html">科幻片</a>
        <a href="/kan/9/1.html">恐怖片</a>
        <a href="/kan/10/1.html">剧情片</a>
        <a href="/kan/11/1.html">战争片</a>
        <a href="/kan/19/1.html">纪录片</a>
        <a href="/kan/20/1.html">微电影</a>
        <a href="/kan/12/1.html">国产剧</a>
        <a href="/kan/13/1.html">香港剧</a>
        <a href="/kan/14/1.html">韩国剧</a>
        <a href="/kan/15/1.html">欧美剧</a>
        <a href="/kan/16/1.html">台湾剧</a>
        <a href="/kan/17/1.html">日本剧</a>
        <a href="/kan/18/1.html">海外剧</a>
        <a href="/kan/26/1.html">内地综艺</a>
        <a href="/kan/27/1.html">港台综艺</a>
        <a href="/kan/28/1.html">日韩综艺</a>
        <a href="/kan/29/1.html">欧美综艺</a>
        <a href="/kan/23/1.html">国产动漫</a>
        <a href="/kan/24/1.html">日韩动漫</a>
        <a href="/kan/25/1.html">欧美动漫</a>
        <a href="/kan/31/1.html">港台动漫</a>
        <a href="/kan/32/1.html">海外动漫</a>
                                                  
                        </dd>
                    </dl>
                </div>
            </div>
        </div>
      
            

            <div class="hy-video-list">
                <div class="item">
                    <ul class="clearfix"> {循环 $new[data] as $v}
 

                                                <li class="col-md-2 col-sm-3 col-xs-4">
                            <a class="videopic lazy" href="/play/{$v[vod_id]}.html" title="{$v[vod_name]}" data-original="{$v[vod_pic]}" style="background: url({$v[vod_pic]}) no-repeat; background-position:50% 50%; background-size: cover;" >
                            <span class="note textbg">{$v[vod_year]}</span>                 </a>
                            <div class="title">
                                <h5 class="text-overflow" title="{$v[vod_name]}"><a href="/play/{$v[vod_id]}.html">{$v[vod_name]}</a></h5>
                            </div>
                            <div class="subtitle text-muted text-overflow hidden-xs"></div>
                        </li>
                                             {结束循环}   
                                            </ul>
                </div>
            </div>
<!-- ​           <div class="hy-page clearfix"> -->
                <ul class="divTags clearfix">
                    <li><a class="text-overflow" href="/kan/{$地址[2]}/1.html">首页</a></li>
                    <li><a class="text-overflow" href="/kan/{$地址[2]}/{$地址[3]-1}.html">上一页</a></li>
                    <li><a class="text-overflow">当前：{$地址[3]}</a></li>
                    <li><a class="text-overflow" href="/kan/{$地址[2]}/{$地址[3]+1}.html">下一页</a></li>
                </ul>
            <!-- </div> -->
        </div>

</div>
    
             
<!-- 结束开始侧面   -->
<div class="sidebar">
            
<div class="widget" id="so">
    <h3 class="widget-title">搜索</h3>        <div class="divSearchPanel clearfix">
        <div name="search"><input type="text" name="q" size="11" placeholder="输入关键词回车搜索" onfocus="" onblur="" onkeypress="if(event.keyCode=='13')\{var hrr='{地址 kan key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);\}" id="keywords"/> <input type="submit" value="搜索" onclick="var hrr='{地址 kan key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);"/></div>    </div>
        </div>
        <!-- 电脑搜索 -->
<div class="widget">
    <h3 class="widget-title">热门文章</h3>            <ul class="divPrevious clearfix">
    {载入 $文章c 搜索 key:state=>on str:dj cou:8}
                        {循环 $文章c[id] as $k=>$v}
                    {载入 $文章 读取 id:$v str:name} 
<li><a href="{地址 read id:$v}">{$文章[name]}</a></li>{结束循环}
    </ul>
    </div>
<!-- 热门文章 -->
<div class="widget">
    <h3 class="widget-title">最新文章</h3>            <ul class="divPrevious clearfix">
    {载入 $文章c 搜索 key:state=>on str:gxtime cou:8}
                        {循环 $文章c[id] as $k=>$v}
                    {载入 $文章 读取 id:$v str:name}
<li><a href="{地址 read id:$v}">{$文章[name]}</a></li>{结束循环}
    </ul>
    </div>
<!-- 最新文章 -->
       
<div class="widget">
    <h3 class="widget-title">标签云</h3>            <ul class="divTags clearfix">
{$标签2[fl]=array_rand($标签[fl],10);} 
                            {循环 $标签2[fl] as $k=>$v}
                            {$过度=$标签[fl][$v]}
<li><a href="{地址 list key:tag id:$过度}">{$标签[info][$过度][name]}<span class="tag-count">{$标签[info][$过度][name]}</span></a></li>
{结束循环}

    </ul>
    </div>
<!-- 标签云        -->
<div class="widget">
    <h3 class="widget-title">友情链接</h3>            <ul class="divLinkage clearfix">
{循环 $友链 as $k=>$v}
<li><a href="{$v[link]}" target="_blank" title="{$v[name]}">{$v[name]}</a></li>{结束循环}
            </ul>
    </div>    </div></div>
<!-- 友情 -->
<!-- 用于图片懒加载 -->


{引用 ./muban/xiaoni/foot.php}