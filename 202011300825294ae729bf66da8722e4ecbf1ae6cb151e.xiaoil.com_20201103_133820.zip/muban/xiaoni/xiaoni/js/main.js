window.stap = {}
$(document).on("click", "[etap]", function() {
    if ($(this).hasClass("disabled")) return !1;
    var e = $(this).attr("etap");
    if (e) {
        var t = e;
        t.indexOf("|") > 0 ? (t = e.split("|")[0], e = e.split("|")[1], "[object Object]" == Object.prototype.toString.call(e) && (e = $.parseJSON(e))) : e = {}, e.name = t, t = t.replace(/-/g, "_"), stap[t] && stap[t]($(this), e)
    }
})
$(function() {
	$(".m-navbar-start").on("click", function() {
		$("body").toggleClass("m-navbar-on")
	})
	$(".m-mask").on("click", function() {
		$("body").removeClass("m-navbar-on"), $("body").removeClass("m-wel-on")
	})
	$(".m-wel-start").on("click", function() {
		$("body").toggleClass("m-wel-on")
	})
	stap.wintips_close = function() {
       $.cookie('wintips', 1, { expires: 1 });
       $(".wintips").fadeOut()
    }
    if($.cookie('wintips')!=1){
       setTimeout(function(){$(".wintips").fadeIn()},1e3)
    }
    var s=document.location;
	$(".site-navbar>ul>li>a").each(function(){
        if(this.href==s.toString().split("#")[0]){$(this).parent().addClass("on");return false;}
        if(this.href==art_cate_url){$(this).parent().addClass("on");return false;}
	});
});