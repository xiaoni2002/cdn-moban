{引用 ./muban/default/head.php}<div class="doc-container" id="doc-container">
    <div class="container-fixed">
        <div class="col-content">
            <div class="inner">
                <section class="article-item zoomIn article">
                    <iframe src="https://1syan.com/?sort=bbs" width="100%" height="600px" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes" id="yk_bbs"></iframe>
                    </section>
        
				

            </div>
        </div>
        <div class="col-other">
            <div class="inner">
                <div class="other-item wow swing" id="categoryandsearch">
                    <div class="search">
                        <label class="search-wrap">
                            <input type="text" id="keyword" placeholder="输入关键字搜索" onkeypress="if(event.keyCode=='13')\{var hrr='{地址 list key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keyword').value);\}"/>
                            <span class="search-icon">
					                <i class="fa fa-search" onclick="var hrr='{地址 list key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keyword').value);" id="serachs"></i>
					            </span>
                        </label>
                    </div>
                </div>
                <!--遮罩-->
                <div class="blog-mask animated layui-hide" style="visibility: hidden"></div>
                <div class="other-item wow swing">
                    <h5 class="other-item-title">热门文章</h5>
                    <div class="inner">
                        <ul class="hot-list-article">{载入 $文章c 搜索 key:state=>on str:dj cou:8}
                        {循环 $文章c[id] as $k=>$v}
                    {载入 $文章 读取 id:$v str:name} 
                                                            <li><a href="{地址 read id:$v}">{$文章[name]}</a></li>{结束循环}
                                                    </ul>
                    </div>
                </div>
                <div class="other-item wow swing">
                    <h5 class="other-item-title">最新文章</h5>
                    <div class="inner">
                        <ul class="hot-list-article">{载入 $文章c 搜索 key:state=>on str:gxtime cou:8}
                        {循环 $文章c[id] as $k=>$v}
                    {载入 $文章 读取 id:$v str:name} 
                                                            <li><a href="{地址 read id:$v}">{$文章[name]}</a></li>{结束循环}
                                                    </ul>
                    </div>
                </div>
                <div class="other-item wow swing">
                    <h5 class="other-item-title">标签云</h5>
                    <div class="inner">
                        <dl class="vistor">{$标签2[fl]=array_rand($标签[fl],10);} 
                            {循环 $标签2[fl] as $k=>$v}
                            {$过度=$标签[fl][$v]}
                                                         <a class="layui-btn layui-btn-primary layui-btn-radius" href="{地址 list key:tag id:$过度}">{$标签[info][$过度][name]}</a>
                                                         
                                                         {结束循环}
                                                    </dl>
                    </div>
                </div>
                
                
                
            </div>
        </div>
    </div>
</div>
{引用 ./muban/default/foot.php}