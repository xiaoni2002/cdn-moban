{引用 ./muban/default/head.php}<style>
    @media screen and (max-width: 1200px){
        .artiledetail img{width: 100%};
    }
</style>


<div class="doc-container" id="doc-container">
    <div class="container-fixed">
        <div class="col-content">
            <div class="inner">
                <article class="article-list">
                    <section class="article-item">
                        <aside class="title" style="line-height:1.5;">
                            <h4>{$内容[name]}</h4>
                            <p class="fc-grey fs-14">
                                <small>
                                    作者：<a href="{地址 list key:author id:$内容[author]}" target="_blank" class="fc-link">{$内容[author]}</a>
                                </small>
                                <small class="ml10">围观群众：<i class="readcount">{$内容[dj]}</i></small>
                                <small class="ml10">更新于 <label>{date("Y-m-d h:i:s",$内容[gxtime])}</label> </small>
                                <small class="ml10">分类：<a href="{地址 list key:type id:$内容[type]}" target="_blank" class="fc-link">{$内容[typename]}</a></small>
                            </p>
                        </aside>
                        <div class="time mt10" style="padding-bottom:0;">
                            <span class="day">{date("d",$内容[gxtime])}</span>
                            <span class="month fs-18">{date("m",$内容[gxtime])}<small class="fs-14">月</small></span>
                            <span class="year fs-18">{date("Y",$内容[gxtime])}</span>
                        </div>
                        <div class="content artiledetail" style="border-bottom: 1px solid #e1e2e0; padding-bottom: 20px;">
                            {$内容[text]}
      
      <div class="copyright mt20" style="border-left: 3px solid #6bc30d;">
                                <p class="f-toe fc-black">
                                    非特殊说明，本文版权归 {$内容[author]} 所有，转载请注明出处.
                                </p>
                                <p class="f-toe">
                                    本文标题：
                                    <a href="#" class="r-title">{$内容[name]}</a>
                                </p>
                                <p class="f-toe">
                                    本文网址：
                                    <a href="#"><script>document.write(window.location.href);</script></a>
                                </p>
                            </div>
                            <ol class="b-relation">
                                <li class="f-toe">上一篇：{判断 $上一篇[name]}<a href="{地址 read id:$上一篇[id]}">{$上一篇[name]}</a>
                                {否则}<a href="#">没有了</a>{结束判断}</li>
                                <li class="f-toe">下一篇：{判断 $下一篇[name]}<a href="{地址 read id:$下一篇[id]}">{$下一篇[name]}</a>
                                {否则}<a href="#">没有了</a>{结束判断}</li>
                            </ol>
                        </div>
                        <div class="f-cb"></div>
                        <div class="mt20 f-fwn fs-24 fc-grey comment" style="padding-top: 20px;">
                        </div>
                        <fieldset class="layui-elem-field layui-field-title">
                            <legend>发表评论</legend>
                            <iframe src="/?sort=bbs" width="100%" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes" id="yk_bbs"></iframe>
                        </fieldset>
                    </section>
                </article>
            </div>
        </div>
	    <div class="col-other">
            <div class="inner">
                <div class="other-item wow swing" id="categoryandsearch">
                    <div class="search">
                        <label class="search-wrap">
                            <input type="text" id="keyword" placeholder="输入关键字搜索" onkeypress="if(event.keyCode=='13')\{var hrr='{地址 list key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keyword').value);\}"/>
                            <span class="search-icon">
					                <i class="fa fa-search" onclick="var hrr='{地址 list key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keyword').value);" id="serachs"></i>
					            </span>
                        </label>
                    </div>
                </div>
                <!--遮罩-->
                <div class="blog-mask animated layui-hide" style="visibility: hidden"></div>
                <div class="other-item wow swing">
                    <h5 class="other-item-title">热门文章</h5>
                    <div class="inner">
                        <ul class="hot-list-article">{载入 $文章c 搜索 key:state=>on str:dj cou:8}
                        {循环 $文章c[id] as $k=>$v}
                    {载入 $文章 读取 id:$v str:name} 
                                                            <li><a href="{地址 read id:$v}">{$文章[name]}</a></li>{结束循环}
                                                    </ul>
                    </div>
                </div>
                <div class="other-item wow swing">
                    <h5 class="other-item-title">最新文章</h5>
                    <div class="inner">
                        <ul class="hot-list-article">{载入 $文章c 搜索 key:state=>on str:gxtime cou:8}
                        {循环 $文章c[id] as $k=>$v}
                    {载入 $文章 读取 id:$v str:name} 
                                                            <li><a href="{地址 read id:$v}">{$文章[name]}</a></li>{结束循环}
                                                    </ul>
                    </div>
                </div>
                <div class="other-item wow swing">
                    <h5 class="other-item-title">标签云</h5>
                    <div class="inner">
                        <dl class="vistor">{$标签2[fl]=array_rand($标签[fl],10);} 
                            {循环 $标签2[fl] as $k=>$v}
                            {$过度=$标签[fl][$v]}
                                                         <a class="layui-btn layui-btn-primary layui-btn-radius" href="{地址 list key:tag id:$过度}">{$标签[info][$过度][name]}</a>
                                                         
                                                         {结束循环}
                                                    </dl>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
{引用 ./muban/default/foot.php}