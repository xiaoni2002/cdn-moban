<footer class="grid-footer">
    <div class="footer-fixed">
        <div class="copyright">
            <div class="info">
                {循环 $友链 as $k=>$v}
                   <a href="{$v[link]}" class="layui-btn layui-btn-normal" target="_blank" style="background-color:#6f736b;">{$v[name]}</a>{结束循环}
                
               	<p class="mt05">
                     这一生一条路走到黑&nbsp;&nbsp;&nbsp;&nbsp;无味无谓也无畏
                </p>
                <p class="mt05">
                    Copyright &copy; 2019-2029 Mr.Yi All Rights Reserved
                </p>
            </div>
        </div>
    </div>
</footer>

<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>

</body>
</html>
