{引用 ./muban/default/head.php}<div class="doc-container" id="doc-container">
    <div class="container-fixed">
        <div class="col-content">
            <div class="inner">
                <article class="article-list bloglist" id="LAY_bloglist">
                    {循环 $内容[id] as $k=>$v}
                    {载入 $文章 读取 id:$v str:name|author|type|gxtime|dj|url|sub|con|tag|yc} 
                <section class="article-item zoomIn article">
                        <div class="fc-flag">{$分类[info][$文章[type]][name]}</div>
                        <h5 class="title">
                            <span class="fc-blue">【{$文章[yc]}】</span>
                            <a href="{地址 read id:$v}" target="_blank">{$文章[name]}</a>
                        </h5>
                        <div class="time">
                            <span class="day">{date("d",$文章[gxtime])}</span>
                            <span class="month fs-18">{date("m",$文章[gxtime])}<span class="fs-14">月</span></span>
                            <span class="year fs-18 ml10">{date("Y",$文章[gxtime])}</span>
                        </div>
                        <div class="content">
                            <a href="{地址 read id:$v}" class="cover img-light">
                                <img target="_blank" src="{判断 $文章[fm]}{$文章[fm]}{否则}/muban/default/static/images/nopic.png{结束判断}">
                            </a>
                        {$文章[mate]}
                        </div>
                        <div class="read-more" style="clear: both">
                            <a href="{地址 read id:$v}" class="fc-black f-fwb" target="_blank">继续阅读</a>
                        </div>
                        <aside class="f-oh footer">
                            <div class="f-fl tags">
                                <span class="fa fa-tags fs-16"></span>
                                {循环 $文章[tagid] as $vs=>$ks}
                                <a class="tag" href="{地址 list key:tag id:$ks}">{$文章[tag][$vs]}</a>
                                {结束循环}
                            </div>
                            <div class="f-fr">
									<span class="read">
										<i class="fa fa-user fs-16"></i>
										<i class="num"><a href="{地址 list key:author id:$文章[author]}">{$文章[author]}</a></i>
									</span>
									<span class="read">
										<i class="fa fa-eye fs-16"></i>
										<i class="num">{$文章[dj]}</i>
									</span>
                
                            </div>
                        </aside>
                    </section>
        {结束循环}
          
        
        
        
            
					
					<section class="article-item zoomIn article">
                        <div class="layui-box layui-laypage layui-laypage-default" id="layui-laypage-1"><a href="{地址 list key:$地址参数[key] id:$地址参数[id] page:1}">首页</a><a href="{地址 list key:$地址参数[key] id:$地址参数[id] page:$内容[prepage]}">上一页</a><span class="layui-laypage-curr"><em class="layui-laypage-em"></em><em>{$地址参数[page]}/{$内容[count]}</em></span><a href="{地址 list key:$地址参数[key] id:$地址参数[id] page:$内容[nexpage]}">下一页</a><a href="{地址 list key:$地址参数[key] id:$地址参数[id] page:$内容[count]}">尾页</a></div>
                    </section>
				

            </div>
        </div>
        <div class="col-other">
            <div class="inner">
                <div class="other-item wow swing" id="categoryandsearch">
                    <div class="search">
                        <label class="search-wrap">
                            <input type="text" id="keyword" placeholder="输入关键字搜索" onkeypress="if(event.keyCode=='13')\{var hrr='{地址 list key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keyword').value);\}"/>
                            <span class="search-icon">
					                <i class="fa fa-search" onclick="var hrr='{地址 list key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keyword').value);" id="serachs"></i>
					            </span>
                        </label>
                    </div>
                </div>
                <!--遮罩-->
                <div class="blog-mask animated layui-hide" style="visibility: hidden"></div>
                <div class="other-item wow swing">
                    <h5 class="other-item-title">热门文章</h5>
                    <div class="inner">
                        <ul class="hot-list-article">{载入 $文章c 搜索 key:state=>on str:dj cou:8}
                        {循环 $文章c[id] as $k=>$v}
                    {载入 $文章 读取 id:$v str:name} 
                                                            <li><a href="{地址 read id:$v}">{$文章[name]}</a></li>{结束循环}
                                                    </ul>
                    </div>
                </div>
                <div class="other-item wow swing">
                    <h5 class="other-item-title">最新文章</h5>
                    <div class="inner">
                        <ul class="hot-list-article">{载入 $文章c 搜索 key:state=>on str:gxtime cou:8}
                        {循环 $文章c[id] as $k=>$v}
                    {载入 $文章 读取 id:$v str:name} 
                                                            <li><a href="{地址 read id:$v}">{$文章[name]}</a></li>{结束循环}
                                                    </ul>
                    </div>
                </div>
                <div class="other-item wow swing">
                    <h5 class="other-item-title">标签云</h5>
                    <div class="inner">
                        <dl class="vistor">{$标签2[fl]=array_rand($标签[fl],10);} 
                            {循环 $标签2[fl] as $k=>$v}
                            {$过度=$标签[fl][$v]}
                                                         <a class="layui-btn layui-btn-primary layui-btn-radius" href="{地址 list key:tag id:$过度}">{$标签[info][$过度][name]}</a>
                                                         
                                                         {结束循环}
                                                    </dl>
                    </div>
                </div>
                
                
                
            </div>
        </div>
    </div>
</div>
{引用 ./muban/default/foot.php}