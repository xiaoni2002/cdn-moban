<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width" />
    <meta name="author" content="colin" />
    <meta name="robots" content="all" />
    <title>{$标题}</title>
    <meta name="keywords" content="{$关键词}">
    <meta name="description" content="{$描述}">
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link href="{$静态CDN}/muban/default/static/css/font-awesome.min.css" rel="stylesheet">
<link href="{$静态CDN}/muban/default/static/css/layui.css" rel="stylesheet">
<link href="{$静态CDN}/muban/default/static/css/master.css" rel="stylesheet">
<link href="{$静态CDN}/muban/default/static/css/gloable.css" rel="stylesheet">
<link href="{$静态CDN}/muban/default/static/css/blog.css" rel="stylesheet">
</head>

<body>
<div class="header"></div>
<header class="gird-header">
    <div class="header-fixed">
        <div class="header-inner">
            <a href="/" class="header-logo" id="logo"><img src="{$静态CDN}/muban/default/static/images/logo.png" height="50px"></a>

            <nav class="nav" id="nav">
<ul><li id="minisearch" style="display:none;"><input type="text"  id="keywords" required="" lay-verify="required" placeholder="输入关键字搜索" autocomplete="off" class="layui-input" onkeypress="if(event.keyCode=='13')\{var hrr='{地址 list key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);\}" style="width:92%;display:inline;"><span class="search-icon">
	<i class="fa fa-search" onclick="var hrr='{地址 list key:name id:keyword}';window.location.href=hrr.replace(/keyword/,document.getElementById('keywords').value);" id="serachs"></i> </span></li>
                    <li{判断 $地址归类=='index'} class="current"{结束判断}><a href="/">首页</a></li>
                    {循环 $分类[info] as $分类号=>$分类名} 
                    <li{判断 $分类号==$内容[type]} class="current"{否则}
                   {判断 $分类号==$地址参数[id] and $地址参数[key]=='type'} class="current"{结束判断}
                   {结束判断}>
                    <a href="{地址 list key:type id:$分类号}">{$分类名[name]}</a></li>{结束循环}
                    <li{判断 $地址参数[sort]=='bbs'} class="current"{结束判断}><a href="/bbs.html">留言板</a></li>
                </ul>
            </nav>
            <a class="phone-menu" onclick="if(document.getElementById('nav').style.display=='block')\{document.getElementById('nav').style.display='';document.getElementById('minisearch').style.display='block';}else\{document.getElementById('nav').style.display='block';document.getElementById('minisearch').style.display='';}">
                <i></i>
                <i></i>
                <i></i>
            </a>
        </div>
    </div>
</header>