<?php 
$plus["XNYS"]["sx"]='4';
$plus["XNYY"]["sx"]='3';
$plus["XNYY"]["state"]='on';
$plus["sitemap"]["sx"]='2';
$plus["sitemap"]["state"]='on';
$plus["ykblog"]["sx"]='1';
$plus["ykblog"]["state"]='on';
