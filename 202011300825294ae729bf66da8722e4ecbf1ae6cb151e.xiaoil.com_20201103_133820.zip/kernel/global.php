<?php
class 数据 
{
	function 固定长度($字符, $长度) 
	{
		if (strlen($字符) < $长度) 
		{
			return str_pad($字符, $长度, ' ', STR_PAD_RIGHT);
		}
		else 
		{
			return substr($字符, 0, $长度);
		}
	}
	function 进制转换($abc, $leix = false) 
	{
		if ($leix === false) 
		{
			return base_convert($abc, 10, 36);
		}
		else 
		{
			return base_convert($abc, 36, 10);
		}
	}
	function 配置($file) 
	{
		$files = file($file);
		$dbykes = str_getcsv($files[1], ';');
		$zhs = 0;
		$dbarr[7] = array();
		for ($i = 1; $i < count($dbykes);
		$i++) 
		{
			$dbykes[$i] = str_getcsv($dbykes[$i]);
			$dbykes[$i][2] = $zhs * 500;
			$dbarr[1][$dbykes[$i][0]] = $i;
			$dbarr[1][$i] = $dbykes[$i];
			$zhs = $zhs + $dbykes[$i][1];
			$dbarr[7][] = $dbykes[$i][0];
		}
		$dbarr[1][0] = $i - 1;
		$dbydbs = str_getcsv($files[2], ';');
		for ($i = 1; $i < count($dbydbs);
		$i++) 
		{
			$dbydbs[$i] = str_getcsv($dbydbs[$i]);
			$dbydbs[$i][2] = $zhs * 500;
			$dbarr[2][$dbydbs[$i][0]] = $i;
			$dbarr[2][$i] = $dbydbs[$i];
			$zhs = $zhs + 10;
			$dbarr[7][] = $dbydbs[$i][0];
		}
		$dbarr[2][0] = $i - 1;
		$dbarr[3] = $files[3];
		$dbarrgd = explode('M', $dbarr[3]);
		$dbarr[3] = $dbarrgd[0] * 1024 * 1024;
		$dbarr[4] = $zhs * 500;
		$dbarr[5] = floor(($dbarr[3] - 100) / $dbarr[4]);
		$dbarr[6] = floor(($dbarr[3] - 100) / 500);
		return $dbarr;
	}
	function 建立数据库($文件名) 
	{
		if (!file_exists($文件名)) 
		{
			file_put_contents($文件名, $this->固定长度('  this is a ykdb file!!<?php exit;?>', 98) . "\r\n");
		}
	}
	function 初始化() 
	{
		$fp = fopen($this->路径 . $this->名称 . '-t.php', "r");
		fseek($fp, 100);
		$sj = str_getcsv(fread($fp, 100));
		fclose($fp);
		return $sj;
	}
	function 数据位置($id) 
	{
		$过度 = ceil($id / 500);
		$str['文件数'] = ceil($过度 / $this->配置[5]);
		$str['组数'] = $过度 - ($str['文件数'] - 1) * $this->配置[5];
		$str['个数'] = $id - ($str['文件数'] - 1) * $this->配置[5] * 500 - ($str['组数'] - 1) * 500;
		return $str;
	}
	function 读取($id, $arr = false) 
	{
		$修改间隔 = time() - filemtime($this->路径 . $this->名称 . '-t.php');
		$fp2 = fopen($this->路径 . $this->名称 . '-t.php', "r+");
		if (fread($fp2, '1') == '2' and $修改间隔 < 5) 
		{
		}
		else 
		{
			fseek($fp2, 0);
			fwrite($fp2, '2');
			fseek($fp2, 1);
			if (fread($fp2, 1) == '2') 
			{
				$this->写删载入($fp2);
			}
			fseek($fp2, 0);
			fwrite($fp2, '11');
			fclose($fp2);
		}
		$this->初始化 = $this->初始化();
		if (empty($id) or $id > $this->初始化[0]) 
		{
			return false;
		}
		$位置 = $this->数据位置($id);
		if (!empty($arr)) 
		{
			$arr = str_getcsv($arr, '|');
		}
		else 
		{
			$arr = $this->配置[7];
		}
		$fp = fopen($this->路径 . $this->名称 . '-' . $位置['文件数'] . '.php', "r+");
		for ($i = 0; $i < count($arr);
		$i++) 
		{
			$k = $arr[$i];
			if (isset($this->配置[1][$k])) 
			{
				fseek($fp, ($位置['组数'] - 1) * $this->配置[4] + $this->配置[1][$this->配置[1][$k]][2] + ($位置['个数'] - 1) * $this->配置[1][$this->配置[1][$k]][1] + 100);
				$数据输出[$k] = trim(fread($fp, $this->配置[1][$this->配置[1][$k]][1]));
			}
			elseif (isset($this->配置[2][$k])) 
			{
				$wz = ($位置['组数'] - 1) * $this->配置[4] + $this->配置[2][$this->配置[2][$k]][2] + ($位置['个数'] - 1) * 10 + 100;
				fseek($fp, $wz);
				$原数据 = $this->进制转换(trim(fread($fp, 10)) , 'y');
				$数据输出[$k] = $this->内容读取($原数据);
			}
		}
		fclose($fp);
		return $数据输出;
	}
	function 内容读取($id) 
	{
		while ($id > 0) 
		{
			$文件数 = ceil($id / $this->配置[6]);
			$个数 = $id - ($文件数 - 1) * $this->配置[6];
			$fp = fopen($this->路径 . $this->名称 . '-n' . $文件数 . '.php', "r+");
			fseek($fp, ($个数 - 1) * 500 + 100);
			$sj.= fread($fp, 490);
			$id = $this->进制转换(fread($fp, 10) , 'y');
			fclose($fp);
		}
		return $sj;
	}
	function 内容写入($id, $str, $id2 = false) 
	{
		$id2 = $this->固定长度($id2, 10);
		$文件数 = ceil($id / $this->配置[6]);
		$个数 = $id - ($文件数 - 1) * $this->配置[6];
		$this->建立数据库($this->路径 . $this->名称 . '-n' . $文件数 . '.php');
		$fp = fopen($this->路径 . $this->名称 . '-n' . $文件数 . '.php', "r+");
		fseek($fp, ($个数 - 1) * 500 + 100);
		fwrite($fp, $this->固定长度($str, 490) . $id2);
		fclose($fp);
	}
	function 内容删除($id, $fp2) 
	{
		while ($id > 0) 
		{
			$删除[] = $this->固定长度($this->进制转换($id) , 10);
			$文件数 = ceil($id / $this->配置[6]);
			$个数 = $id - ($文件数 - 1) * $this->配置[6];
			$fp = fopen($this->路径 . $this->名称 . '-n' . $文件数 . '.php', "r+");
			$wz = ($个数 - 1) * 500 + 100;
			fseek($fp, $wz + 490);
			$id = $this->进制转换(fread($fp, 10) , 'y');
			fseek($fp, $wz);
			fwrite($fp, $this->固定长度('', 500));
			fclose($fp);
		}
		fseek($fp2, 200);
		$删除填充 = $this->进制转换(trim(fread($fp2, '10')) , 'y');
		fseek($fp2, 200);
		fwrite($fp2, $this->固定长度($this->进制转换($删除填充 + count($删除)) , 10));
		fseek($fp2, 10 * $删除填充 + 210);
		fwrite($fp2, implode('', $删除));
	}
	function 写入子函数($数组, $id, $fp2) 
	{
		$this->初始化 = $this->初始化();
		if (empty($id) or $id > $this->初始化[0]) 
		{
			$id = $this->初始化[0] + 1;
			$id总数 = $id;
		}
		else 
		{
			$id总数 = $this->初始化[0];
		}
		fseek($fp2, 100);
		$内容总数 = $this->初始化[1];
		$位置 = $this->数据位置($id);
		$this->建立数据库($this->路径 . $this->名称 . '-' . $位置['文件数'] . '.php');
		$fp = fopen($this->路径 . $this->名称 . '-' . $位置['文件数'] . '.php', "r+");
		foreach ($数组 as $k => $v) 
		{
			if (isset($this->配置[1][$k])) 
			{
				fseek($fp, ($位置['组数'] - 1) * $this->配置[4] + $this->配置[1][$this->配置[1][$k]][2] + ($位置['个数'] - 1) * $this->配置[1][$this->配置[1][$k]][1] + 100);
				fwrite($fp, $this->固定长度($v, $this->配置[1][$this->配置[1][$k]][1]));
			}
			elseif (isset($this->配置[2][$k])) 
			{
				$wz = ($位置['组数'] - 1) * $this->配置[4] + $this->配置[2][$this->配置[2][$k]][2] + ($位置['个数'] - 1) * 10 + 100;
				fseek($fp, $wz);
				$原数据 = $this->进制转换(trim(fread($fp, 10)) , 'y');
				fseek($fp, $wz);
				if ($原数据 > 0) 
				{
					$this->内容删除($原数据, $fp2);
				}
				$v = str_split($v, 490);
				fseek($fp2, 200);
				$删除填充 = $this->进制转换(trim(fread($fp2, '10')) , 'y');
				if ($删除填充 >= 10 and count($v) <= $删除填充) 
				{
					$删除编号 = fread($fp2, $删除填充 * 10);
					$删除编号 = str_split($删除编号, 10);
					for ($b = 0; $b < count($v);
					$b++) 
					{
						if ($b == '0') 
						{
							fwrite($fp, $删除编号[0]);
						}
						if ($b !== count($v) - 1) 
						{
							$gd = $b + 1;
							$gd = $删除编号[$gd];
						}
						else 
						{
							$gd = '';
						}
						$this->内容写入($this->进制转换($删除编号[$b], 'a') , $v[$b], $gd);
						unset($删除编号[$b]);
					}
					fseek($fp2, 200);
					fwrite($fp2, $this->固定长度($this->进制转换(count($删除编号)) , 10) . implode('', $删除编号));
				}
				else 
				{
					for ($b = 0; $b < count($v);
					$b++) 
					{
						$内容总数 = $内容总数 + 1;
						if ($b == '0') 
						{
							fwrite($fp, $this->固定长度($this->进制转换($内容总数) , 10));
						}
						if ($b !== count($v) - 1) 
						{
							$gd = $内容总数 + 1;
							$gd = $this->固定长度($this->进制转换($gd) , 10);
						}
						else 
						{
							$gd = '';
						}
						$this->内容写入($内容总数, $v[$b], $gd);
					}
				}
			}
		}
		fseek($fp2, 100);
		fwrite($fp2, $this->固定长度($id总数 . ',' . $内容总数, 100));
		fclose($fp);
		return $id;
	}
	function 写入($数组, $id = false) 
	{
		$修改间隔 = time() - filemtime($this->路径 . $this->名称 . '-t.php');
		$this->建立数据库($this->路径 . $this->名称 . '-t.php');
		$fp2 = fopen($this->路径 . $this->名称 . '-t.php', "r+");
		if (fread($fp2, '1') == '2' and $修改间隔 < 5) 
		{
			file_put_contents($this->路径 . $this->名称 . 'z-' . $this->毫秒时间戳() . '-' . rand(1, 3) , 'x-' . $this->固定长度($id, 20) . '-' . json_encode($数组));
			fseek($fp2, 1);
			fwrite($fp2, '2');
		}
		else 
		{
			fseek($fp2, 0);
			fwrite($fp2, '2');
			$返回 = $this->写入子函数($数组, $id, $fp2);
			fseek($fp2, 1);
			if (fread($fp2, 1) == '2') 
			{
				$this->写删载入($fp2);
			}
			fseek($fp2, 0);
			fwrite($fp2, '11');
			fclose($fp2);
			return $返回;
		}
	}
	function 写删载入($fp2) 
	{
		$files = scandir($this->路径);
		for ($i = 0; $i < count($files);
		$i++) 
		{
			if (strstr($files[$i], $this->名称 . 'z-')) 
			{
				$cs = file_get_contents($this->路径 . $files[$i]);
				if (substr($cs, 0, 1) == 'd') 
				{
					$this->删除子函数(trim(substr($cs, 2, 20)) , trim(substr($cs, 23)) , $fp2);
					unlink($this->路径 . $files[$i]);
				}
				elseif (substr($cs, 0, 1) == 'x') 
				{
					$this->写入子函数(json_decode(trim(substr($cs, 23)) , TRUE) , trim(substr($cs, 2, 20)) , $fp2);
					unlink($this->路径 . $files[$i]);
				}
			}
		}
	}
	function 删除子函数($id, $arr, $fp2) 
	{
		$this->初始化 = $this->初始化();
		if (empty($id) or $id > $this->初始化[0]) 
		{
			return false;
		}
		$位置 = $this->数据位置($id);
		if (!empty($arr)) 
		{
			$arr = str_getcsv($arr, '|');
		}
		else 
		{
			$arr = $this->配置[7];
		}
		$fp = fopen($this->路径 . $this->名称 . '-' . $位置['文件数'] . '.php', "r+");
		for ($i = 0; $i < count($arr);
		$i++) 
		{
			$k = $arr[$i];
			if (isset($this->配置[1][$k])) 
			{
				fseek($fp, ($位置['组数'] - 1) * $this->配置[4] + $this->配置[1][$this->配置[1][$k]][2] + ($位置['个数'] - 1) * $this->配置[1][$this->配置[1][$k]][1] + 100);
				fwrite($fp, $this->固定长度('', $this->配置[1][$this->配置[1][$k]][1]));
			}
			elseif (isset($this->配置[2][$k])) 
			{
				$wz = ($位置['组数'] - 1) * $this->配置[4] + $this->配置[2][$this->配置[2][$k]][2] + ($位置['个数'] - 1) * 10 + 100;
				fseek($fp, $wz);
				$原数据 = $this->进制转换(trim(fread($fp, 10)) , 'y');
				if ($原数据 > 0) 
				{
					$this->内容删除($原数据, $fp2);
				}
			}
		}
		fclose($fp);
	}
	function 删除($id, $arr = false) 
	{
		$修改间隔 = time() - filemtime($this->路径 . $this->名称 . '-t.php');
		$fp2 = fopen($this->路径 . $this->名称 . '-t.php', "r+");
		if (fread($fp2, '1') == '2' and $修改间隔 < 5) 
		{
			file_put_contents($this->路径 . $this->名称 . 'z-' . $this->毫秒时间戳() . '-' . rand(1, 3) , 'd-' . $this->固定长度($id, 20) . '-' . $arr);
			fseek($fp2, 1);
			fwrite($fp2, '2');
		}
		else 
		{
			fseek($fp2, 0);
			fwrite($fp2, '2');
			$this->删除子函数($id, $arr, $fp2);
			fseek($fp2, 1);
			if (fread($fp2, 1) == '2') 
			{
				$this->写删载入($fp2);
			}
			fseek($fp2, 0);
			fwrite($fp2, '11');
			fclose($fp2);
		}
	}
	function 毫秒时间戳() 
	{
		$tim = microtime();
		$tim = explode(' ', $tim);
		$tim[0] = explode('.', $tim[0]);
		return $tim[0][1];
	}
	function 搜索($arr, $id = false) 
	{
		$this->初始化 = $this->初始化();
		$arr = explode('|', $arr);
		for ($i = 0; $i < count($arr);
		$i++) 
		{
			$arr[$i] = explode('=>', $arr[$i]);
			if (!empty($arr[$i][1]) or $arr[$i][1] == '0') 
			{
				if ($this->配置[1][$arr[$i][0]] > 0) 
				{
					$id = $this->搜索子函数($arr[$i][0], $arr[$i][1], $id);
					if (empty($id)) 
					{
						return false;
					}
				}
			}
		}
		return $id;
	}
	function 搜索子函数($变量, $条件, $id) 
	{
		$长度 = $this->配置[1][$this->配置[1][$变量]][1];
		$数据信息 = $this->数据位置($this->初始化[0]);
		if (is_array($id)) 
		{
			$array = true;
			for ($k = 1; $k <= $数据信息['文件数']; $k++) 
			{
				$fpgd = 'fp' . $k;
				$$fpgd = fopen($this->路径 . $this->名称 . '-' . $k . '.php', "r");
			}
			for ($p = 0; $p < count($id);
			$p++) 
			{
				$位置 = $this->数据位置($id[$p]);
				$fpgd = 'fp' . $位置['文件数'];
				fseek($$fpgd, ($位置['组数'] - 1) * $this->配置[4] + $this->配置[1][$this->配置[1][$变量]][2] + ($位置['个数'] - 1) * $this->配置[1][$this->配置[1][$变量]][1] + 100);
				$数据串.= fread($$fpgd, $this->配置[1][$this->配置[1][$变量]][1]);
			}
			for ($k = 1; $k <= $数据信息['文件数']; $k++) 
			{
				$fpgd = 'fp' . $k;
				fclose($$fpgd);
			}
		}
		else 
		{
			$array = false;
			for ($k = 1; $k <= $数据信息['文件数']; $k++) 
			{
				$fp = fopen($this->路径 . $this->名称 . '-' . $k . '.php', "r");
				for ($p = 1; $p <= $数据信息['组数']; $p++) 
				{
					fseek($fp, ($p - 1) * $this->配置[4] + $this->配置[1][$this->配置[1][$变量]][2] + 100);
					$数据串.= fread($fp, 500 * $长度);
				}
				fclose($fp);
			}
		}
		if ($this->搜索模式 == '严格') 
		{
			$条件 = $this->固定长度($条件, $长度);
		}
		$长度2 = strlen($条件);
		$数据串 = explode($条件, $数据串);
		if (count($数据串) > 1) 
		{
			for ($m = 0; $m < count($数据串) - 1;
			$m++) 
			{
				$数据长度 = $数据长度 + strlen($数据串[$m]) + $长度2;
				$ss = ceil($数据长度 / $长度);
				if (!$pd[$ss]) 
				{
					if ($array) 
					{
						$st = $ss - 1;
						$jg[] = $id[$st];
					}
					else 
					{
						$jg[] = $ss;
					}
				}
				$pd[$ss] = true;
			}
			return $jg;
		}
		else 
		{
			return false;
		}
	}
	function 排序($变量, $升降 = false, $id = false) 
	{
		$this->初始化 = $this->初始化();
		$数据信息 = $this->数据位置($this->初始化[0]);
		if (empty($变量) or $this->配置[1][$变量] <= '0') 
		{
			return false;
		}
		for ($k = 1; $k <= $数据信息['文件数']; $k++) 
		{
			$fpgd = 'fp' . $k;
			$$fpgd = fopen($this->路径 . $this->名称 . '-' . $k . '.php', "r");
		}
		if (is_array($id)) 
		{
			for ($p = 0; $p < count($id);
			$p++) 
			{
				$位置 = $this->数据位置($id[$p]);
				$fpgd = 'fp' . $位置['文件数'];
				fseek($$fpgd, ($位置['组数'] - 1) * $this->配置[4] + $this->配置[1][$this->配置[1][$变量]][2] + ($位置['个数'] - 1) * $this->配置[1][$this->配置[1][$变量]][1] + 100);
				$arr[$id[$p]] = trim(fread($$fpgd, $this->配置[1][$this->配置[1][$变量]][1]));
			}
		}
		else 
		{
			for ($p = 1; $p <= $this->初始化[0]; $p++) 
			{
				$位置 = $this->数据位置($p);
				$fpgd = 'fp' . $位置['文件数'];
				fseek($$fpgd, ($位置['组数'] - 1) * $this->配置[4] + $this->配置[1][$this->配置[1][$变量]][2] + ($位置['个数'] - 1) * $this->配置[1][$this->配置[1][$变量]][1] + 100);
				$arr[$p] = trim(fread($$fpgd, $this->配置[1][$this->配置[1][$变量]][1]));
			}
		}
		for ($k = 1; $k <= $数据信息['文件数']; $k++) 
		{
			$fpgd = 'fp' . $k;
			fclose($$fpgd);
		}
		if ($升降 == '升') 
		{
			arsort($arr);
		}
		else 
		{
			asort($arr);
		}
		return array_keys($arr);
	}
	function 数组分页($数组, $页码 = '1', $单页数 = '20') 
	{
		if ($页码 <= 1 or empty($页码)) 
		{
			$页码 = 1;
		}
		if ($单页数 <= 1 or empty($单页数)) 
		{
			$单页数 = 20;
		}
		$总页数 = ceil(count($数组) / $单页数);
		if ($页码 > $总页数) 
		{
			$页码 = $总页数;
		}
		$起始位置 = ($页码 - 1) * $单页数;
		$arr = array_slice($数组, $起始位置, $单页数);
		$arr['count'] = $总页数;
		return $arr;
	}
}
mkdir(DATA . '/cms/');
mkdir(DATA . '/cache/');
function 反斜杠($str) 
{
	return str_replace('\'', '\\\'', $str);
}
function 分类($sort = false, $数据 = false) 
{
	if (!is_array($数据) and strstr($数据, ':')) 
	{
		$数据 = 冒号解析($数据);
	}
	$分类路径 = DATA . '/cms/type.txt';
	$分类 = json_decode(file_get_contents($分类路径) , TRUE);
	if ($sort == '写入') 
	{
		if ($数据['id'] == false) 
		{
			if (empty($分类)) 
			{
				$分类[1] = array( 'name' => $数据['name'], 'dname' => $数据['dname'], 'gs' => $数据['gs'], 'state' => $数据['state'] );
			}
			else 
			{
				$分类[] = array( 'name' => $数据['name'], 'dname' => $数据['dname'], 'gs' => $数据['gs'], 'state' => $数据['state'] );
			}
		}
		else 
		{
			$分类[$数据['id']] = array( 'name' => $数据['name'], 'dname' => $数据['dname'], 'gs' => $数据['gs'], 'state' => $数据['state'] );
		}
		file_put_contents($分类路径, json_encode($分类, 320));
		return true;
	}
	elseif ($sort == '删除') 
	{
		file_put_contents($分类路径, json_encode($分类, 320));
		return true;
	}
	else 
	{
		foreach ($分类 as $key => $val) 
		{
			if (!empty($val[gs])) 
			{
				$分类1['fl2'][$val[gs]][] = $key;
			}
			else 
			{
				$分类1['fl1'][] = $key;
			}
			$分类1['info'][$key]['dname'] = $val['dname'];
			$分类1['info'][$key]['name'] = $val['name'];
			$分类1['info'][$key]['gs'] = $val['gs'];
			$分类1['info'][$key]['state'] = $val['state'];
			$分类1['dname'][$val['dname']] = $key;
			$分类1['name'][$val['name']] = $key;
		}
		return $分类1;
	}
}
function 标签($sort = false, $数据 = false) 
{
	if (!is_array($数据) and strstr($数据, ':')) 
	{
		$数据 = 冒号解析($数据);
	}
	$分类路径 = DATA . '/cms/tags.txt';
	$分类 = json_decode(file_get_contents($分类路径) , TRUE);
	if ($sort == '写入') 
	{
		if ($数据['id'] == false) 
		{
			if (empty($分类)) 
			{
				$分类[1] = array( 'name' => $数据['name'], 'dname' => $数据['dname'] );
			}
			else 
			{
				$分类[] = array( 'name' => $数据['name'], 'dname' => $数据['dname'] );
			}
		}
		else 
		{
			$分类[$数据['id']] = array( 'name' => $数据['name'], 'dname' => $数据['dname'] );
		}
		file_put_contents($分类路径, json_encode($分类, 320));
		foreach ($分类 as $key => $val) 
		{
			if ($val['name'] == $数据['name']) 
			{
				return $key;
			}
		}
		return true;
	}
	elseif ($sort == '删除') 
	{
		file_put_contents($分类路径, json_encode($分类, 320));
		return true;
	}
	else 
	{
		foreach ($分类 as $key => $val) 
		{
			$分类1['fl'][] = $key;
			$分类1['info'][$key]['dname'] = $val['dname'];
			$分类1['info'][$key]['name'] = $val['name'];
			$分类1['info'][$key]['state'] = $val['state'];
			$分类1['dname'][$val['dname']] = $key;
			$分类1['name'][$val['name']] = $key;
		}
		return $分类1;
	}
}
function 友链($sort = false, $数据 = false) 
{
	if (!is_array($数据) and strstr($数据, ':')) 
	{
		$数据 = 冒号解析($数据);
	}
	$友链路径 = DATA . '/cms/link.txt';
	$友链 = json_decode(file_get_contents($友链路径) , TRUE);
	if ($sort == '写入') 
	{
		$友链[$数据['id']] = array( 'name' => $数据['name'], 'link' => $数据['link'], 'logo' => $数据['logo'] );
		$友链 = array_values($友链);
		file_put_contents($友链路径, json_encode($友链, 320));
		return true;
	}
	elseif ($sort == '删除') 
	{
		unset($友链[$数据['id']]);
		$友链 = array_values($友链);
		file_put_contents($友链路径, json_encode($友链, 320));
		return true;
	}
	else 
	{
		return $友链;
	}
}
function 读写删($sort, $内容 = false) 
{
	if (!is_array($内容) and strstr($内容, ':')) 
	{
		$内容 = 冒号解析($内容);
	}
	$数据 = new 数据();
	$数据->路径 = DATA . '/cms/';
	$数据->名称 = 'ykcms';
	$数据->配置 = $数据->配置(KERNEL . '/data.php');
	global $分类;
	global $标签;
	if ($sort == '写入') 
	{
		if (!empty($内容['key']) or !empty($内容['mate']) or !empty($内容['fm']) or !empty($内容['mod'])) 
		{
			$内容['sub'] = json_encode(array( 'key' => $内容['key'], 'mate' => $内容['mate'], 'fm' => $内容['fm'], 'mod' => $内容['mod'] ) , 320);
		}
		return $数据->写入($内容, $内容['id']);
	}
	elseif ($sort == '删除') 
	{
		$数据->删除($内容);
		return true;
	}
	elseif ($sort == '读取') 
	{
		$结果 = $数据->读取($内容['id'], $内容['str']);
		if (!empty($结果['sub'])) 
		{
			$结果['sub'] = json_decode($结果['sub'], TRUE);
			$结果['key'] = $结果['sub']['key'];
			$结果['mate'] = $结果['sub']['mate'];
			$结果['fm'] = $结果['sub']['fm'];
			$结果['mod'] = $结果['sub']['mod'];
			unset($结果['sub']);
		}
		if (!empty($结果['tag'])) 
		{
			$tags = explode(',', $结果['tag']);
			$结果['tag'] = array();
			for ($i = 0; $i < count($tags);
			$i++) 
			{
				$结果['tag'][] = $标签['info'][$tags[$i]]['name'];
				$结果['tagid'][] = $tags[$i];
			}
		}
		if (!empty($结果['type'])) 
		{
			$结果['typename'] = $分类['info'][$结果['type']]['name'];
		}
		return $结果;
	}
	elseif ($sort == '搜索') 
	{
		if (!empty($内容['key'])) 
		{
			$id集合 = $数据->搜索($内容['key']);
			if (empty($id集合)) 
			{
				return false;
			}
		}
		if (empty($内容['page'])) 
		{
			$内容['page'] = '1';
		}
		if (empty($内容['cou'])) 
		{
			$内容['cou'] = 10;
		}
		if (empty($内容['str']) and !empty($内容['key'])) 
		{
			$内容1 = 数组分页($id集合, $内容['page'], $内容['cou']);
		}
		else 
		{
			if (empty($内容['str'])) 
			{
				$内容['str'] = 'fbtime';
			}
			$id集合 = $数据->排序($内容['str'], '升', $id集合);
			$内容1 = $数据->数组分页($id集合, $内容['page'], $内容['cou']);
		}
		$结果[count] = $内容1[count];
		$结果[prepage] = $内容['page'] - 1;
		$结果[nexpage] = $内容['page'] + 1;
		if ($结果[prepage] < 1) 
		{
			$结果[prepage] = 1;
		}
		if ($结果[nexpage] > $结果[count]) 
		{
			$结果[nexpage] = $结果[count];
		}
		unset($内容1[count]);
		$结果[id] = $内容1;
		return $结果;
	}
}
function 模块($sort, $内容 = false) 
{
	if (!is_array($内容) and strstr($内容, ':')) 
	{
		$内容 = 冒号解析($内容);
	}
	$数据 = new 数据();
	$数据->路径 = DATA . '/cms/';
	$数据->名称 = 'mod';
	$数据->配置 = $数据->配置(KERNEL . '/mod.php');
	if ($sort == '写入') 
	{
		return $数据->写入($内容, $内容['id']);
	}
	elseif ($sort == '删除') 
	{
		$数据->删除($内容);
		return true;
	}
	elseif ($sort == '读取') 
	{
		$结果 = $数据->读取($内容['id'], $内容['str']);
		return $结果;
	}
	elseif ($sort == '搜索') 
	{
		if (!empty($内容['key'])) 
		{
			$id集合 = $数据->搜索($内容['key']);
			if (empty($id集合)) 
			{
				return false;
			}
		}
		if (empty($内容['page'])) 
		{
			$内容['page'] = '1';
		}
		$id集合 = $数据->排序('gxtime', '升', $id集合);
		$内容1 = $数据->数组分页($id集合, $内容['page'], $内容['cou']);
		$结果[count] = $内容1[count];
		$结果[prepage] = $内容['page'] - 1;
		$结果[nexpage] = $内容['page'] + 1;
		if ($结果[prepage] < 1) 
		{
			$结果[prepage] = 1;
		}
		if ($结果[nexpage] > $结果[count]) 
		{
			$结果[nexpage] = $结果[count];
		}
		unset($内容1[count]);
		$结果[id] = $内容1;
		return $结果;
	}
}
function 伪静态() 
{
	$rules_md5 = md5(REWRITERULES);
	if (file_exists(DATA . '/cache/rewrite_' . $rules_md5 . '.txt')) 
	{
		$规则 = json_decode(file_get_contents(DATA . '/cache/rewrite_' . $rules_md5 . '.txt') , TRUE);
	}
	else 
	{
		preg_match_all('#([^\s]*?):([^\s]*)#', REWRITERULES, $规则);
		for ($i = 0; $i < count($规则[1]);
		$i++) 
		{
			$规则s2 = preg_replace('#\{(.*?),(.*?)\}#', '{\\1}', $规则[1][$i]);
			preg_match_all('#\{(.*?)\}#', $规则s2, $match);
			$规则s = preg_replace('#\{([^,]*?)\}#', '(.*?)', $规则[1][$i]);
			$规则s = preg_replace('#\{(.*?),(.*?)\}#', '\\2', $规则s);
			$规则[1][$i] = array( 'r' => $规则s, 'c' => $规则s2, 'k' => $match[1] );
		}
		file_put_contents(DATA . '/cache/rewrite_' . $rules_md5 . '.txt', json_encode($规则, 320));
	}
	return $规则;
}
function 地址($地址) 
{
	$规则 = 伪静态();
	$参数 = 冒号解析('sort:' . $地址);
	for ($i = 0; $i < count($规则[2]);
	$i++) 
	{
		if ($规则[2][$i] == $参数['sort']) 
		{
			$匹配 = $规则[1][$i];
			if (count($规则[1][$i][k]) + 1 == count($参数)) 
			{
				break;
			}
		}
	}
	if (empty($匹配)) 
	{
		$地址 = 'index.html';
	}
	else 
	{
		$地址 = $匹配[c];
		foreach ($参数 as $k => $v) 
		{
			$地址 = str_replace('{' . $k . '}', $v, $地址);
		}
	}
	if (REWRITE !== 'on') 
	{
		$地址 = '?' . $地址;
	}
	global $网址替换;
	$地址 = str_replace($网址替换[1], $网址替换[2], $地址);
	return PATH . $地址;
}
function 地址参数($地址 = false) 
{
	$规则 = 伪静态();
	if (empty($地址)) 
	{
		$地址 = $_SERVER['REQUEST_URI'];
	}
	$地址 = str_replace('?', '', $地址);
	$地址 = urldecode($地址);
	global $网址替换;
	$地址 = str_replace($网址替换[2], $网址替换[1], $地址);
	for ($i = 0; $i < count($规则[1]);
	$i++) 
	{
		if (preg_match('#/' . $规则[1][$i]['r'] . '#', $地址, $match)) 
		{
			$参数['sort'] = $规则[2][$i];
			for ($m = 1; $m < count($match);
			$m++) 
			{
				$n = $m - 1;
				$参数[$规则[1][$i]['k'][$n]] = $match[$m];
			}
			break;
		}
	}
	if (empty($参数['sort'])) 
	{
		$参数['sort'] = 'index';
	}
	return $参数;
}
function 冒号解析($str) 
{
	preg_match_all('#([^\s]*?):([^\s]*)#', $str, $match);
	for ($i = 0; $i < count($match[1]);
	$i++) 
	{
		if (!empty($match[2][$i])) 
		{
			$ma[$match[1][$i]] = $match[2][$i];
		}
	}
	return $ma;
}
function mhjx($str) 
{
	preg_match_all('#(.*?):(.*)#', $str, $match);
	for ($i = 0; $i < count($match[1]);
	$i++) 
	{
		if (!empty($match[2][$i])) 
		{
			$ma[$match[1][$i]] = $match[2][$i];
		}
	}
	return $ma;
}
function 插件排序() 
{
	global $plus;
	foreach ($plus as $k => $v) 
	{
		if ($v['state'] == 'on') 
		{
			$插件[$v['sx']] = $k;
		}
	}
	krsort($插件);
	return $插件;
}
function muban($str) 
{
	if (strstr($str, '.php')) 
	{
		$路径 = DATA . '/cache/' . md5_file($str) . '.php';
	}
	else 
	{
		$路径 = DATA . '/cache/' . md5($str) . '.php';
	}
	if (!file_exists($路径)) 
	{
		if (strstr($str, '.php')) 
		{
			$模板内容 = file_get_contents($str);
		}
		else 
		{
			$模板内容 = $str;
		}
		$模板内容 = str_replace(array( '{结束判断}', '{结束循环}', '{否则}', '{跳出循环}', '\\{', '\\}', '{$标题}', '{$关键词}', '{$描述}' ) , array( '<?php }?>', '<?php }?>', '<?php }else{?>', '<?php break;?>', 'imzkh', 'imykh', '<?php include $标题;?>', '<?php include $关键词;?>', '<?php include $描述;?>' ) , $模板内容);
		$模板内容 = preg_replace(array( '#\{([A-Z]+)\}#', '#\{循环([\s]*)([^\?]*?)([\s]*)as([\s]*)(.*?)\}#', '#{判断([\s]*)([^\?]*?)}#', '#{否则([\s]*)([^\?]*?)}#', '#{引用([\s]*)([^\?]*?)}#', '#{地址([\s]*)([^\?]*?)}#', '#{载入([\s]*)\$([^} \?]*)([\s]*)([^} ]*)([\s]*)(.*?)}#', '#\{\$([^=?]*?)\}#', '#\{\$([^\?]*?)\}#', '#\{([^\?]*?)\(([^\?]*?)\}#' ) , array( '<?php echo \\1;?>', '<?php foreach(\\2 as \\5){?>', '<?php if(\\2){?>', '<?php }elseif(\\2){?>', '<?php include muban("\\2");?>', '<?php echo 地址("\\2");?>', '<?php $\\2=读写删("\\4","\\6");?>', '<?php echo $\\1;?>', '<?php $\\1;?>', '<?php echo \\1(\\2;?>' ) , $模板内容);
		$模板内容 = str_replace(array( 'imzkh', 'imykh' ) , array( '{', '}' ) , $模板内容);
		file_put_contents($路径, $模板内容);
	}
	return $路径;
}
function 地址加密($str) 
{
	$str = urlencode(base64_encode(gzcompress($str)));
	return '/?u=' . $str;
}
function 数组分页($数组, $页码 = '1', $单页数 = '20') 
{
	if ($页码 <= 1 or empty($页码)) 
	{
		$页码 = 1;
	}
	if ($单页数 <= 1 or empty($单页数)) 
	{
		$单页数 = 20;
	}
	$总页数 = ceil(count($数组) / $单页数);
	if ($页码 > $总页数) 
	{
		$页码 = $总页数;
	}
	$数组 = array_reverse($数组);
	$起始位置 = ($页码 - 1) * $单页数;
	$arr = array_slice($数组, $起始位置, $单页数);
	$arr['count'] = $总页数;
	return $arr;
}
?>