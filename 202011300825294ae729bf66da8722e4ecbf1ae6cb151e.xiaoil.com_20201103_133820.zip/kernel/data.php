hashconfig<?php exit;?>//数据存储设定，第一行为可定字节长度变量，第一位为主ID，依次以  变量名1,字符数1;变量名2,字符数2 进行填写，第二行为大容量字符串存储，依次以 变量名1;变量名2 进行填写，第三行为设置单个sql文件最大容量（以M为单位）。
;name,100;author,20;type,5;fbtime,10;gxtime,10;dj,10;yc,6;tag,20;zt,5;top,5;state,5
;text;sub
100M
//text 正文 ，sub 关键词，描述，封面 key,mate,fm