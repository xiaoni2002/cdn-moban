<?php
$sitemap=json_decode(file_get_contents(DATA.'/sitemap/rules.txt'),TRUE);
    if(!empty($post['time'])){
        mkdir(DATA.'/sitemap/');
        file_put_contents(DATA.'/sitemap/rules.txt',json_encode($post,320));echo 'OK';exit;
    }
    include './muban/muban.html'; include PLUS.'/sitemap/admin_index.html';