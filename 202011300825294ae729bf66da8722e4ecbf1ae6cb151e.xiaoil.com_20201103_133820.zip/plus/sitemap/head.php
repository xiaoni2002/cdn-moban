<?php
$sitemapconfig=json_decode(file_get_contents(DATA.'/sitemap/rules.txt'),TRUE);
if(time()-filemtime('./sitemap.xml') >$sitemapconfig['time']*60){
$arraysitemap['key']='state=>on';$arraysitemap['str']='gxtime';
$数据 = new 数据();
$数据->路径 = DATA.'/cms/';
$数据->名称 = 'xncms';
$数据->配置 = $数据->配置(KERNEL.'/data.php');
$id集合=$数据->搜索('state=>on');
$id集合=$数据->排序('gxtime','升',$id集合);
$fp=fopen("./sitemap.xml","w+");
fwrite($fp,'<?xml version="1.0" encoding="UTF-8"?>
<urlset>	
	<url>
		<loc>https://xiaoil.com</loc>
		<priority>1.00</priority>
		<lastmod>'.date("Y-m-d").'</lastmod>
		<changefreq>hourly</changefreq>
	</url>');

for($i=0;$i<count($id集合);$i++){
$sitemapnr=$数据->读取($id集合[$i],'gxtime');
fwrite($fp,'
    <url>
		<loc>https://xiaoil.com'.地址('read id:'.$id集合[$i]).'</loc>
		<priority>0.8</priority>
		<lastmod>'.date("Y-m-d",$sitemapnr['gxtime']).'</lastmod>
		<changefreq>daily</changefreq>
	</url>');
}
fwrite($fp,'
</urlset>');
fclose($fp);
}
