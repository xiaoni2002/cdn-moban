﻿var wenkmList=[{
song_album:"",
song_album1:"",
song_file:"/",

song_name:"Alan Walker - Faded|Alan Walker - The Spectre|Alan Walker - Alone".split("|"),		//添加网易云音乐id+wy 用 | 隔开

song_id:"36990266wy|506092035wy|444269135wy".split("|") 		//添加网易云音乐id+wy 用 | 隔开

}];