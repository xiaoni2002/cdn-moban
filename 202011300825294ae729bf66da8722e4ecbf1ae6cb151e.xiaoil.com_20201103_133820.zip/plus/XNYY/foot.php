<?php
if ($地址参数['sort']=='play') {
} else {

}
// print_r($地址参数);判断影视页面不显示
if ($地址参数['sort']=='kan') {
} else
if ($地址参数['sort']=='play') {
} else 
 {?>
	<script id="ilt" src="https://player.ilt.me/player/js/player.js" key="2a42807985c34460b3344814a838b169"></script>
<?php }?>