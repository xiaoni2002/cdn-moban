<?php
$XNYY=json_decode(file_get_contents(DATA.'/XNYY/rules.txt'),TRUE);
    if(!empty($post['id']+$post['name'])){
        mkdir(DATA.'/XNYY/');
        file_put_contents(DATA.'/XNYY/rules.txt',json_encode($post,320));echo 'OK';exit;
    }
    include './muban/muban.html'; include PLUS.'/XNYY/admin_index.html';