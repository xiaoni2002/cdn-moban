<?php $XNYYconfig=json_decode(file_get_contents(DATA.'/XNYY/rules.txt'),TRUE);?>
   <!--播放器开始 记得更换为自己的网易云ID--> 
<script type="text/javascript" src="/plus/XNYY/js/jquery.min.js"></script>
﻿<script>auto="open";random="open";name="<?php echo $XNYYconfig['name'] ?>";geci="colse";user="<?php echo $XNYYconfig['id'] ?>";welcome="open";tips="<?php echo $XNYYconfig['title'] ?>";</script>
<script type="text/javascript" src="/plus/XNYY/js/Admlonln.js"></script>
  <!--播放器结束 -->  