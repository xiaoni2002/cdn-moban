<?php
$fp=fopen(DATA.'/cms/ykcms-t.php',"r");fseek($fp,100);
$sj=str_getcsv(fread($fp,100));fclose($fp);
$总文章=$sj[0];
if($地址参数['sort']=='index' or $地址参数['sort']=='list'){
    if(empty($地址参数['page'])){$地址参数['page']=1;}
    $array['page']=$地址参数['page'];
    if($地址参数['sort']!=='index'){$array['key']=$地址参数['key'].'=>'.$地址参数['id'].'|';}
    $array['key'].='state=>on';
    $内容=读写删('搜索',$array);
    if($地址参数['sort']=='index'){
    $地址参数['sort']='list';
    $地址归类='index';}
}elseif($地址参数['sort']=='read'){
    $内容=读写删('读取',array('id'=>$地址参数['id']));
    $内容[dj]=$内容[dj]+1;
    读写删('写入',array('id'=>$地址参数['id'],'dj'=>$内容[dj]));
    $preid=$地址参数['id']-1;
    $nexid=$地址参数['id']+1;
    while(!$上一篇[name] and $preid>=1){
        $上一篇=读写删('读取',array('id'=>$preid,'str'=>'name'));if(!empty($上一篇[name])){$上一篇[id]=$preid;}$preid=$preid-1;
    }
    while(!$下一篇[name] and $nexid<=$总文章){
        $下一篇=读写删('读取',array('id'=>$nexid,'str'=>'name'));if(!empty($下一篇[name])){$下一篇[id]=$nexid;}$nexid=$nexid+1;
    }
    
    
preg_match('#<p(.*?)</p>#',$内容[text],$match);
if(preg_match('#<img([^>]*?)src="(.*?)"#',$match[0],$matchs)){$内容[text]=str_replace($match[0],'',$内容[text]);}


if(!empty($内容['mod'])){$内容['mod']=explode(',',$内容['mod']);
$模块 = new 数据();
$模块->路径 = DATA.'/cms/';
$模块->名称 = 'mod';
$模块->配置 = $模块->配置(KERNEL.'/mod.php');
$模块->搜索模式='严格';
for($i=0;$i<count($内容['mod']);$i++){
$搜索模块=$模块->搜索('name=>'.$内容[mod][$i]);
if(!empty($搜索模块)){$模块数据[$i]=$模块->读取($搜索模块[0],'type|text');
if($模块数据[$i]['type']=='s'){${$内容[mod][$i]}=冒号解析($模块数据[$i]['text']);}else{${$内容[mod][$i]}=$模块数据[$i]['text'];}
}
}
preg_match_all('#\{\$([^\}]*)\}#',$内容[text],$match);
for($i=0;$i<count($match[0]);$i++){
eval('$替换=$'.$match[1][$i].';');
$内容[text]=str_replace($match[0][$i],$替换,$内容[text]);}
preg_match_all('#\{([^\}]*)\(([^\}]*)\)\}#',$内容[text],$match);
for($i=0;$i<count($match[0]);$i++){
$过度模块=${$match[1][$i]};$ssss=explode(',',$match[2][$i]);
for($k=0;$k<count($ssss);$k++){${模块变量.$k}=${$ssss[$k]};} 
preg_match_all('#\{\$([^\}]*)\}#',$过度模块,$matchs);
for($m=0;$m<count($matchs[1]);$m++){
  eval('$替换=$'.$matchs[1][$m].';');
  $过度模块=str_replace($matchs[0][$m],$替换,$过度模块);
}
$内容[text]=str_replace($match[0][$i],$过度模块,$内容[text]);}
}
$内容[text]=preg_replace_callback('#地址加密\(([^\)]*?)\)#',function($match){return 地址加密($match[1]);},$内容[text]);

$内容[text]=preg_replace_callback('#\{文档加密 (.*?) (.*?)\}(.*?)\{加密结束\}#is',function($match){if($_COOKIE[$match[1]]==$match[2]){return $match[3];}else{return '<br><br><input type="password" id="'.$match[1].'" placeholder="以下内容被加密，请输入密码回车后查看" onkeypress="if(event.keyCode==\'13\'){document.cookie=\''.$match[1].'=\'+document.getElementById(\''.$match[1].'\').value;location.reload();}" style="padding-left:20px;width:90%;border: 2px solid red;border-radius: 40px;height: 40px;"><br><br>';}},$内容[text]);
}



$keymate=冒号解析(KEYMATE);
if($地址归类=='index'){
    $标题=muban($keymate['index-title']);
    $关键词=muban($keymate['index-key']);
    $描述=muban($keymate['index-mate']);
}else{
    $标题=muban($keymate[$地址参数['sort'].'-title']);
    $关键词=muban($keymate[$地址参数['sort'].'-key']);
    $描述=muban($keymate[$地址参数['sort'].'-mate']);  
}
