<html><head>
<meta charset="utf-8">
<title>XN-CMS内容管理系统</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="../publics/layui/css/layui.css" media="all">
<link rel="stylesheet" href="../publics/iconfont/iconfont.css" media="all">
</head>
<body class="childrenBody">
<div class="row">
	<div class="sysNotice col">
		<blockquote class="layui-elem-quote title">系统基本参数</blockquote>
		<table class="layui-table">
			<colgroup>
				<col width="150">
				<col>
			</colgroup>
			<tbody>
				<tr>
					<td>网站域名</td>
					<td>http://<?php echo $_SERVER['HTTP_HOST']; ?></td>
				</tr>
				<tr>
					<td>网站目录</td>
					<td><?php echo $_SERVER['DOCUMENT_ROOT']; ?></td>
				</tr>
				<tr>
					<td>操作系统</td>
					<td><?php echo PHP_OS; ?></td>
				</tr>
				<tr>
					<td>服务引擎</td>
					<td><?php echo $_SERVER['SERVER_SOFTWARE']; ?></td>
				</tr>
				<tr>
					<td>环境版本</td>
					<td>PHP <?php echo @phpversion(); ?></td>
				</tr>
				<tr>
					<td>上传限制</td>
					<td><?php echo get_cfg_var("upload_max_filesize");?></td>
				</tr>
				
			</tbody>
		</table>
	</div>
	<div class="sysNotice col">
		<blockquote class="layui-elem-quote title">最新文章</blockquote>
		<table class="layui-table" lay-skin="line">
			<colgroup>
				<col>
				<col width="110">
			</colgroup>
			<tbody class="hot_news">
<tr>
	<td colspan="2">
		暂无新增内容
	</td>
</tr>
			</tbody>
		</table> 
	</div>
</div>
<script type="text/javascript" src="../publics/layui/layui.js"></script>
<script type="text/javascript" src="js/index.js"></script>

</body></html>