<?php
error_reporting(0);
date_default_timezone_set('PRC');
function curlgets($url,$data,$head) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
   curl_setopt($ch, CURLOPT_POST, 1);
   curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $f = curl_exec($ch);
    curl_close($ch);
    return $f;
}
$head=array('X-Token:Dm-mufvC.35978.MAtuKcF6P2BY','Content-Type: application/json','Accept: application/json');
$post=$_POST;

//加载文件夹信息
define('CONFIG','../config');
define('PLUS','../plus');
define('KERNEL','../kernel');
define('DATA','../data');

include CONFIG.'/config.php';
include CONFIG.'/plus.php';
include CONFIG.'/guanggao.php';
include KERNEL.'/global.php';

if(!empty($post['mod'])){$post['mod']=explode(',',$post['mod']);
$模块 = new 数据();
$模块->路径 = DATA.'/cms/';
$模块->名称 = 'mod';
$模块->配置 = $模块->配置(KERNEL.'/mod.php');
$模块->搜索模式='严格';
for($i=0;$i<count($post['mod']);$i++){
$搜索模块=$模块->搜索('name=>'.$post[mod][$i]);
if(!empty($搜索模块)){$模块数据[$i]=$模块->读取($搜索模块[0],'type|text');
if($模块数据[$i]['type']=='s'){${$post[mod][$i]}=冒号解析($模块数据[$i]['text']);}else{${$post[mod][$i]}=$模块数据[$i]['text'];}
}
}
preg_match_all('#\{\$([^\}]*)\}#',$post['text'],$match);
for($i=0;$i<count($match[0]);$i++){
eval('$替换=$'.$match[1][$i].';');
$post['text']=str_replace($match[0][$i],$替换,$post['text']);}
preg_match_all('#\{([^\}]*)\(([^\}]*)\)\}#',$post['text'],$match);
for($i=0;$i<count($match[0]);$i++){
$过度模块=${$match[1][$i]};$ssss=explode(',',$match[2][$i]);
for($k=0;$k<count($ssss);$k++){${模块变量.$k}=${$ssss[$k]};} 
preg_match_all('#\{\$([^\}]*)\}#',$过度模块,$matchs);
for($m=0;$m<count($matchs[1]);$m++){
  eval('$替换=$'.$matchs[1][$m].';');
  $过度模块=str_replace($matchs[0][$m],$替换,$过度模块);
}
$post['text']=str_replace($match[0][$i],$过度模块,$post['text']);}
}
$post['text']=strip_tags($post['text']);$post['text']=str_replace(' ','',$post['text']);
if($post[sort]=='keywords'){
    $u='http://api.bosonnlp.com/keywords/analysis?top_k='.$post[num];
    $data=array($post[text]);
    $cs=curlgets($u,json_encode($data),$head);
    $cs=json_decode($cs,TRUE);
    for($i=0;$i<count($cs[0]);$i++){$css.=','.$cs[0][$i][1];}
    echo substr($css,'1');
}
elseif($post[sort]=='summary'){
    $num=$post[num] / 1;
    $u='http://api.bosonnlp.com/summary/analysis';
    $data=array('not_exceed'=> 1,
    'percentage'=> $num,
    'content'=>$post[text]);
    $cs=curlgets($u,json_encode($data),$head);$cs=str_replace('\n','',$cs);
    echo substr($cs,1,-1);
}
