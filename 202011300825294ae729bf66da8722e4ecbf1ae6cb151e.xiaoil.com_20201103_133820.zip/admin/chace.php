<html><head>
<meta charset="utf-8">
<title>内容管理系统</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="../publics/layui/css/layui.css" media="all">
<link rel="stylesheet" href="../publics/iconfont/iconfont.css" media="all">
<link rel="stylesheet" href="css/admin.css" media="all">
<style>
.layui-form-pane .layui-form-label{width:200px;text-align:right;}
.layui-form-pane .layui-input-block{margin-left:200px;}
</style>
<script language="javascript">
function resetCookieEncode()
{
	jQuery.get("sys_info.php?dopost=make_encode", function(data){
		jQuery("#edit___cfg_cookie_encode").val(data);
	});
}
</script>
<link id="layuicss-skinlayercss" rel="stylesheet" href="http://z.com/zm/publics/layui/css/modules/layer/default/layer.css?v=3.0.3303" media="all"></head>
<div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
    <ul class="layui-tab-title">
<li class="layui-this">缓存清理</li>
    </ul>
<div class="layui-tab-content">



       <body>
<?php $nav = 'cache';?>
<div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
    <ul class="layui-tab-title">
<li class="layui-this">缓存设置</li>
    </ul>
<div class="layui-tab-content">

        <div class="layui-tab-item layui-show">
<div id="hd_main">
    
  <a<?php echo $_GET['c']=='0'?' class="layui-btn"':''?> class="layui-btn" href="./cache.php?act=cache&c=0">清除列表缓存</a>
     </div>
</div><!--main-->
   

<?php
if(isset($_GET['c']) && isset($_GET['act']) && $_GET['act']=='cache') {
    $c = $_GET['c'];
    switch($c){
        case '0':
        $path = '../moban/data/list/';
        deleteAll($path);
        break;
    }
}
?>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
  <legend>XS提醒1</legend>
</fieldset> 
<ul class="layui-timeline">
  <li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis">注意</i>
    <div class="layui-timeline-content layui-text">
      <div class="layui-timeline-title">如非必要请不要点击清除，如果文件很多，会卡死你。</div>
    </div>
  </li>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
  <legend>XS提醒2</legend>
</fieldset> 
<ul class="layui-timeline">
  <li class="layui-timeline-item">
    <i class="layui-icon layui-timeline-axis">注意</i>
    <div class="layui-timeline-content layui-text">
      <div class="layui-timeline-title">缓存是为了加速访问，删掉缓存不会影响之前的收录，只是会再去抓取数据。
      空间不够用的话，定期手动删掉部分缓存可以节省空间占用。</div>
    </div>
  </li>

<script type="text/javascript" src="layui/layui.js"></script>
<script>
layui.use(['form','element'], function(){
  var element = layui.element()
  ,var form = layui.form(); //导航的hover效果、二级菜单等功能，需要依赖element模块
</script>

		
<script type="text/javascript" src="../publics/layui/layui.js"></script>
<script type="text/javascript" src="js/sysinfo.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/zeroclipboard.js"></script>

</body></html>