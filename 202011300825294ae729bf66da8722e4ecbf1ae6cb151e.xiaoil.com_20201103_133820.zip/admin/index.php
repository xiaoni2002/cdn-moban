<?php
error_reporting(0);
date_default_timezone_set('PRC');
//基础信息
$name='XN-CMS';

//登录模块
if($_GET[sort]=='logout'){setcookie("u_Cookie",'');setcookie("p_Cookie",'');header("Location:index.php");exit;}
include './config.php';
if(empty($_COOKIE['u_Cookie']) or empty($_COOKIE['p_Cookie'])or empty($用户[$_COOKIE['u_Cookie']])){include './muban/login.html';exit;}
elseif(md5($用户[$_COOKIE['u_Cookie']])==$_COOKIE['p_Cookie']){$dlpd='y';}
else{setcookie('u_Cookie','');setcookie('p_Cookie','');echo"<script>alert('用户名或密码错误!!!');location.href='index.php';</script>";exit;}



//加载文件夹信息
define('CONFIG','../config');
define('PLUS','../plus');
define('KERNEL','../kernel');
define('DATA','../data');

include CONFIG.'/config.php';
include CONFIG.'/plus.php';
include CONFIG.'/guanggao.php';
include KERNEL.'/global.php';


$get=$_GET;$post=$_POST;
$分类=分类();$标签=标签();
//主进程


//分类管理
if($get['sort']=='type'){ 
if($get['ac']=='edit'){
    if(!empty($post['name'])){
    分类('写入',array('id'=>$post['id'],'name'=>$post['name'],'dname'=>$post['dname'],'gs'=>$post['gs'],'state'=>$post['state']));
    echo 'OK';exit;
    }
     include './muban/muban.html';include './muban/type_add.html';
}elseif($get['ac']=='del'){
    分类('删除',$get['id']);echo 'OK';exit;
}else{
     include './muban/type_index.html';}
}


//关键词管理 tag
elseif($get['sort']=='key'){
if($get['ac']=='edit'){
    if(!empty($post['name'])){
    标签('写入',array('id'=>$post['id'],'name'=>$post['name'],'dname'=>$post['dname']));
    echo 'OK';exit;
    }
     include './muban/muban.html';include './muban/tag_add.html';
}elseif($get['ac']=='del'){
    标签('删除',$get['id']);echo 'OK';exit;
}else{
     include './muban/tag_index.html';}
}


//文章管理
elseif($get['sort']=='edit'){
if($get['ac']=='edit'){
    $内容=读写删('读取',array('id'=>$get['id']));
    if(!empty($post['name'])){
        $post['text']=preg_replace('#<pre([^>]*?)>#','<pre class="layui-code">',$post['text']);
    preg_match('#<p(.*?)</p>#',$post['text'],$match);
    preg_match('#<img([^>]*?)src="(.*?)"#',$match[0],$match);$post['fm']=$match[2];
    if(empty($post['id'])){$post['fbtime']=time();}$post['gxtime']=time();
    if($内容['dj']<1){$post['dj']='0';}
    $tag=explode(',',$post['tag']);$post['tag']='';
    for($i=0;$i<count($tag);$i++){
        unset($ids);
        if(!empty($tag[$i])){if(empty($标签['name'][$tag[$i]])){
            $ids=标签('写入',array('name'=>$tag[$i]));$post['tag'].=','.$ids;
        }else{$post['tag'].=','.$标签['name'][$tag[$i]];}
            
        }
    }
    $post['tag']=substr($post['tag'],1);
    读写删('写入',$post);
    echo 'OK';exit;
    }
    
     include './muban/muban.html';include './muban/edit_add.html';
}elseif($get['ac']=='del'){
    读写删('删除',$get['id']);echo 'OK';exit;
}else{
    if(!empty($get['key'])){
    $列表=读写删('搜索',array('page'=>$get['page'],'key'=>'name=>'.$get['key']));}else{$列表=读写删('搜索',array('page'=>$get['page']));}
     include './muban/muban.html';include './muban/edit_index.html';}
}



//网站设置
elseif($get['sort']=='set'){
    $变量=array(
        array('网站名','NAME','输入网站名称','input')
        ,array('副标题','SEO','输入副标题','input')
        ,array('英文名','ENAME','输入英文名','input')
        ,array('路径','PATH','输入网站相对路径','input')
        ,array('模板','MUBAN','选择启用模板','select')
        ,array('邮箱','MAIL','输入站长邮箱','input')
        ,array('QQ','QQ','输入联系QQ','input')
        ,array('伪静态','REWRITE','开关伪静态','checkbox')
        // ,array('列表描述关键词','LIST','描述','textarea')
        ,array('伪静态规则','REWRITERULES','伪静态规则','textarea','layui-form-text')
        ,array('标题、关键词、描述','KEYMATE','标题、关键词、描述','textarea','layui-form-text')
        );
    if(!empty($post['NAME'])){
        $str='<?php '."\r\n";
        foreach($post as $k=>$v){
            $str.='define(\''.$k.'\',\''.反斜杠($v).'\');'."\r\n";
        }
        file_put_contents(CONFIG.'/config.php',$str);
    echo 'OK';exit;
    }
     include './muban/muban.html';include './muban/set.html';
}



//友链管理
elseif($get['sort']=='link'){
    $友链=友链();
if($get['ac']=='edit'){
    if(!empty($post['name'])){
    友链('写入',$post);
    echo 'OK';exit;
    }
     include './muban/muban.html';include './muban/link_add.html';
}elseif($get['ac']=='del'){
    友链('删除',$get['id']);echo 'OK';exit;
}else{
     include './muban/link_index.html';}
}



//模块
elseif($get['sort']=='mod'){
if($get['ac']=='edit'){

    if(!empty($post['name'])){

$post['gxtime']=time();
    模块('写入',$post);
    echo 'OK';exit;
    }
    $内容=模块('读取',array('id'=>$get['id']));
     include './muban/muban.html';include './muban/mod_add.html';
}elseif($get['ac']=='del'){
模块('删除',$get['id']);echo 'OK';exit;
}else{
        if(!empty($get['key'])){
    $列表=模块('搜索',array('page'=>$get['page'],'key'=>'name=>'.$get['key']));}else{$列表=模块('搜索',array('page'=>$get['page']));}
     include './muban/mod_index.html';}
}




//插件设置
elseif($get['sort']=='plus'){
$文件夹=scandir(PLUS.'/');
    if(!empty($post)){
        $str='<?php '."\r\n";
        foreach($post as $k=>$v){
            $k=explode('-',$k);
            $str.='$plus["'.$k[0].'"]["'.$k[1].'"]=\''.$v.'\';'."\r\n";
        }
        file_put_contents(CONFIG.'/plus.php',$str);
    echo 'OK';exit;
    }
     include './muban/muban.html';include './muban/plus.html';
}



//密码管理
elseif($get['sort']=='pass'){
    if(!empty($post['user'])){
    file_put_contents('./config.php','<?php $用户['.$post['user'].']="'.$post['pass'].'";?>');
    echo 'OK';exit;
    }
     include './muban/muban.html';include './muban/pass.html';
}


//三方插件
elseif($get['sort']=='sfplus'){
    include PLUS.'/'.$get['pid'].'/admin.php';
}


//首页
else{include './muban/head.html'; include './muban/index.html';include './muban/foot.html';}





//print_r($分类);
//分类('写入',array('id'=>1,'name'=>'随便','dname'=>'sb','gs'=>''));//分类('删除','1');分类();//分类的读写删
//标签('写入',array('id'=>1,'name'=>'随便','dname'=>'sb'));//标签('删除','1');标签();//标签的读写删

//读写删('写入',array('name'=>'第一篇','author'=>'admin','type'=>'sb','fbtime'=>time(),'gxtime'=>time(),'dj'=>'0','dz'=>'0','tag'=>'sb','zt'=>'1','url'=>'','nr'=>'哈哈哈哈哈','key'=>'','mate'=>'','fm'=>''));//修改array带'id'=>'1',删除'fbtime','dj','dz',其余不涉及变量删除，需要删除的变量用 空格替换
//$数据=读写删('读取',array('id'=>'1'));//读取 array可以带'str'=>'name|author'等读取特定变量
//print_r($数据);